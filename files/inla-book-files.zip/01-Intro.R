## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/01-Intro-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
GoT <- read.csv2(file = "data/GoT.csv")
summary(GoT)


## ----label = "GoT", fig = TRUE, echo = FALSE, fig.cap = "Likelihood and prior of the number of u's on a page of Game of Thrones."----
library("ggplot2")
library("gridExtra")
xx <- seq(1, 60, by = 0.01)

got.prior <- dgamma(xx, 180, 6)
got.lik <- sapply(xx, function(lambda) {
 exp(sum(dpois(GoT$Us, lambda, log = TRUE)))
})

tab1 <- data.frame(xx, got.prior)
p1 <- ggplot(tab1, aes(x = xx, y = got.prior)) + geom_line() +
  ggtitle("Prior distribution") +
  xlab(expression(lambda)) + ylab("density")

tab2 <- data.frame(xx, got.lik)
p2 <- ggplot(tab2, aes(x = xx, y = got.lik)) + geom_line() +
  ggtitle("Likelihood") +
  xlab(expression(lambda)) + ylab("likelihood")

grid.arrange(p1, p2, ncol = 1)


## -----------------------------------------------------------------------------
mean(GoT$Us)


## -----------------------------------------------------------------------------
got.logposterior <- function(lambda) {
  dgamma(lambda, 180, 6, log = TRUE) + sum(dpois(GoT$Us, lambda,
    log = TRUE))
}

#Maximize log-posterior
got.MAP <- optim(30, got.logposterior, control = list(fnscale = -1))
got.MAP$par


## ----label = "GoTpost", fig = TRUE, echo = FALSE, fig.cap = "Posterior distribution of the number of u's in a book of Game of Thrones using a conjugate prior (black solid line) and MAP estimate (dotted red line)."----
a.post <- 180 + sum(GoT$Us)
b.post <- 6 + nrow(GoT)

got.post <- dgamma(xx, a.post, b.post)

tab.cp <- data.frame(xx, got.post)
ggplot(tab.cp, aes(x = xx, y = got.post)) + geom_line() +
  ggtitle("Posterior distribution") +
  xlab(expression(lambda)) + 
  ylab(expression(paste(pi, "(", lambda, " | ", bold(y), ")"))) +
  geom_vline(xintercept = got.MAP$par, linetype = "dotted", colour = "red") +
  xlim(25, 40)


## -----------------------------------------------------------------------------
n.sim <- 2100
lambda <- rep(NA, n.sim)
lambda[1] <- 20


## -----------------------------------------------------------------------------
set.seed(1)
for (i in 2:n.sim) {
  # Draw new value
  lambda.new <- rlnorm(1, log(lambda[i - 1]), 0.05)

  #Log-acceptance probability
  acc.prob <- dlnorm(lambda[i -1], log(lambda.new), 0.05, log = TRUE) + 
    dgamma(lambda.new, 180, 6, log = TRUE) +
    sum(dpois(GoT$Us, lambda.new, log = TRUE)) -
    dlnorm(lambda.new, log(lambda[i - 1]), 0.05, log = TRUE) -
    dgamma(lambda[i - 1], 180, 6, log = TRUE) -
    sum(dpois(GoT$Us, lambda[i - 1], log = TRUE))

  acc.prob <- min(1, exp(acc.prob))

  # Accept/reject new value  
  if(runif(1) < acc.prob) {
    lambda[i] <- lambda.new
  } else {
    lambda[i] <- lambda[i -1]
  }

}


## -----------------------------------------------------------------------------
lambda2 <- lambda[seq(101, n.sim, by = 5)]


## -----------------------------------------------------------------------------
summary(lambda2)


## ----label = "GoTMH", fig = TRUE, echo = FALSE, fig.cap = '(ref:GoTMH)'-------
library("ggplot2")
library("gridExtra")

tab.sim <- data.frame(iter = 1:n.sim, lambda = lambda)

tab.labels <- data.frame(
  x = c(0, 500),
  y = c(36, 36),
  text = c("burn-in", "inference")
)

# MCMC chain
p1 <- ggplot(tab.sim, aes(x = iter, y = lambda)) + geom_line() +
  xlab("Iteration") + 
  ylab(expression(lambda)) + 
  geom_vline(xintercept = 100, linetype = "dashed", colour = "red") +
  geom_text(data = tab.labels, aes(x = x, y = y, label = text)) +
  ggtitle("Metropolis-Hastings samples")

# Density plot
dens.lambda <- as.data.frame(density(lambda2, bw = 0.4)[c("x", "y")])
p2 <- ggplot(dens.lambda, aes(x = x, y = y)) + geom_line() +
  xlab(expression(lambda)) +
  ylab(expression(paste(pi, "(", lambda, " | ", bold(y), ")"))) +
  #ylab("density") +
  ggtitle("Posterior density")

grid.arrange(p1, p2, ncol = 1)



## -----------------------------------------------------------------------------
GoT.inla <- inla(Us ~ 1, data = GoT, family = "poisson",
  control.predictor = list(compute = TRUE)
) 


## -----------------------------------------------------------------------------
GoT.inla$summary.fixed


## -----------------------------------------------------------------------------
marg.lambda <- inla.tmarginal(exp, GoT.inla$marginals.fixed[[1]])
inla.est <- inla.zmarginal(marg.lambda)


## ----echo = FALSE, results = "asis"-------------------------------------------
tab.est <- data.frame(
  Method = c("Max. lik.", "MAP", "Conjugate", "M-H", "INLA"),
  Mean = c(NA, NA, a.post / b.post,
    mean(lambda), inla.est$mean),
  Mode = c(mean(GoT$Us), got.MAP$par, (a.post - 1) / b.post, 
    dens.lambda[which.max(dens.lambda[, 2]), 1],
    marg.lambda[which.max(marg.lambda[, 2]), 1]),
  Stdev = c(NA, NA, sqrt(a.post / b.post^2),
    sd(lambda), inla.est$sd),
  q025 = c(NA, NA, qgamma(0.025, a.post, b.post),
    quantile(lambda, 0.025), inla.est$quant0.025),
  q975 = c(NA, NA, qgamma(0.975, a.post, b.post),
    quantile(lambda, 0.975), inla.est$quant0.975)
)

names(tab.est) <- c("**Method**", "**Mean**", "**Mode**", "**St. dev.**",
  "**0.025 quant.**", "**0.975 quant.**") 

knitr::kable(tab.est, format = "markdown", escape = FALSE, longtable=FALSE,
  caption = "Table: (\\#tab:GoTestimates) Summary of estimates using different Bayesian estimation methods.")
cat("\nTable: (\\#tab:GoTestimates) Summary of estimates using different Bayesian estimation methods.\n")


## ----echo = FALSE, label = "bayesinf", fig = TRUE, fig.cap = '(ref:bayesinf)', fig.width = 6, fig.height = 2, fig.pos = "H"----

# Marginal from INLA
marg.lambda <- as.data.frame(marg.lambda)
names(marg.lambda) <- c("x", "y")

# Density plot
ggplot(dens.lambda, aes(x = x, y = y)) + geom_line() +
  xlab(expression(lambda)) +
  geom_line(data = tab.cp, aes(x = xx, y = got.post), lty = 2) +
  geom_line(data = marg.lambda, aes(x = x, y = y), lty = 3) +
  geom_vline(xintercept = got.MAP$par, linetype = "dotted", colour = "red") +
  ylab(expression(paste(pi, "(", lambda, " | ", bold(y), ")"))) +
  #ggtitle("Posterior density") + 
  xlim(25, 40)


