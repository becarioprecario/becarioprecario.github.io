## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library(knitr)
opts_chunk$set(
  fig.path = 'figs/03-GLMM-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## ----message = FALSE-----------------------------------------------------
library(spdep)
data(nc.sids)

# Overall rate
r <- sum(nc.sids$SID74) / sum(nc.sids$BIR74)
nc.sids$EXP74 <- r * nc.sids$BIR74

# Proportion of non-white births
nc.sids$NWPROP74 <- nc.sids$NWBIR74 / nc.sids$BIR74


## ----message = FALSE-----------------------------------------------------
m.pois.lin1 <- inla(SID74 ~ f(NWPROP74, model = "linear"),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.lin1)


## ----message = FALSE-----------------------------------------------------
library("INLA")
m.pois.clin1 <- inla(SID74 ~ f(NWPROP74, model = "clinear",
  range = c(0, Inf)), data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.clin1)


## ------------------------------------------------------------------------
nc.sids$ID <- 1:100


## ------------------------------------------------------------------------
m.pois.iid <- inla(SID74 ~ f(ID, model = "iid"),
  data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.iid)


## ------------------------------------------------------------------------
m.pois.iid2 <- inla(SID74 ~ NWPROP74 + f(ID, model = "iid"),
  data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.iid2)


## ------------------------------------------------------------------------
m.pois.z <- inla(SID74 ~ f(ID, model = "z", Z = Diagonal(nrow(nc.sids), 1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.z)


## ------------------------------------------------------------------------
m.pois.g0 <- inla(SID74 ~ f(ID, model = "generic0", 
  Cmatrix = Diagonal(nrow(nc.sids), 1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.g0)


## ------------------------------------------------------------------------
K1 <- Diagonal(nrow(nc.sids), 1)

m.pois.g2 <- inla(SID74 ~ f(ID, model = "generic3", Cmatrix = list(K1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.g2)


## ------------------------------------------------------------------------
#Overall rate
r79 <- sum(nc.sids$SID79) / sum(nc.sids$BIR79)
nc.sids$EXP79 <- r79 * nc.sids$BIR79


## ------------------------------------------------------------------------
#New data.frame
nc.new <- data.frame(SID = c(nc.sids$SID74, nc.sids$SID79),
  EXP = c(nc.sids$EXP74, nc.sids$EXP79),
  PERIOD = as.factor(c(rep("74", 100), rep("79", 100))),
  ID = 1:200)


## ------------------------------------------------------------------------
m.pois.iid2d <- inla(SID ~ 0 + PERIOD + f(ID, model = "iid2d", n = 2 * 100),
  data = nc.new, family = "poisson", E = EXP)

summary(m.pois.iid2d)


## ----label = "sids-iid2d", fig = TRUE, echo = FALSE, fig.cap = '(ref:sids-iid2d)'----
plot(m.pois.iid2d$summary.random$ID$mean[1:100],
  m.pois.iid2d$summary.random$ID$mean[100 + 1:100],
  xlab = expression(u[i]), ylab = expression(v[i])
)
abline(0, 1)


## ------------------------------------------------------------------------
data(AirPassengers)

airp.data <- data.frame(airp = as.vector(AirPassengers),
  month = as.factor(rep(1:12, 12)), 
  year = as.factor(rep(1949:1960, each = 12)),
  ID = 1:length(AirPassengers))


## ----label = "airp", fig = TRUE, echo = FALSE, fig.cap = "Monthly international airline passengers: original data (top) and log-scale (bottom).", fig.width = 5, fig.height = 8----
par(mfrow = c(2, 1))

plot(AirPassengers, main = "Number of international passengers")

plot(log(AirPassengers),
  main = "Number of international passengers (log-scale)")



## ------------------------------------------------------------------------
airp.rw1 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "rw1"),
  data = airp.data, control.predictor = list(compute = TRUE))
summary(airp.rw1)


## ------------------------------------------------------------------------
airp.rw2 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "rw2"),
  data = airp.data, control.predictor = list(compute = TRUE))
summary(airp.rw2)



## ----label = "airp-rw", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers."----
plot(log(AirPassengers),
  main = "Number of international passengers (log-scale)")
lines(as.vector(time(AirPassengers)),
  airp.rw1$summary.fitted.values$mean, lty = 2)
lines(as.vector(time(AirPassengers)),
  airp.rw2$summary.fitted.values$mean, lty = 3)

legend("topleft", legend = c("data", "RW1", "RW2"), lty = 1:3, bty = "n")


## ------------------------------------------------------------------------
airp.seasonal <- inla(log(AirPassengers) ~ 0 + year +
    f(ID, model = "seasonal", season.length = 12),
  data = airp.data)

summary(airp.seasonal)


## ------------------------------------------------------------------------
airp.ar1 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "ar1"),
  data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar1)


## ------------------------------------------------------------------------
airp.ar3 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "ar",
  order = 3), data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar3)


## ------------------------------------------------------------------------
Z <- model.matrix (~ 0 + year, data = airp.data)
Q.beta <- Diagonal(12, 0.001)

airp.ar1c <- inla(log(AirPassengers) ~ 1 + f(ID, model = "ar1c",
  args.ar1c = list(Z = Z, Q.beta = Q.beta)),
  data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar1c)


## ----label = "airp-ar", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers using autoregressive models."----
plot(log(AirPassengers),
  main = "Number of international passengers (log-scale)")
lines(as.vector(time(AirPassengers)),
  airp.ar1$summary.fitted.values$mean, lty = 2)
lines(as.vector(time(AirPassengers)),
  airp.ar3$summary.fitted.values$mean, lty = 3)
lines(as.vector(time(AirPassengers)),
  airp.ar1c$summary.fitted.values$mean, lty = 4)

legend("topleft", legend = c("data", "AR(1)", "AR(3)", "AR(1) with cov."),
  lty = 1:4, bty = "n")


## ------------------------------------------------------------------------
names(inla.models()$latent$iid)


## ------------------------------------------------------------------------
prec.prior <- inla.models()$latent$iid$hyper$theta
prec.prior


## ----eval = FALSE--------------------------------------------------------
## hyper = list(prec = list(prior = "gaussian", param = c(0, 0.001)))


## ------------------------------------------------------------------------
m.pois.iid.gp <- inla(SID74 ~ f(ID, model = "iid",
    hyper = list(theta = list(prior = "gaussian", param = c(0, 0.001)))),
  data = nc.sids, family = "poisson",
  E = EXP74)
summary(m.pois.iid.gp)


## ----eval = FALSE--------------------------------------------------------
## hyper = list(theta = list(prior = "gaussian", param = c(0, 0.001)))


## ----eval = FALSE--------------------------------------------------------
## hyper = list(theta1 = list(...), theta2 = list(...))


## ------------------------------------------------------------------------
inla.models()$latent$rw1$constr


## ------------------------------------------------------------------------
inla.models()$latent$iid$constr


## ------------------------------------------------------------------------
m.pois.iid.gp0 <- inla(SID74 ~ f(ID, model = "iid", constr = TRUE),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.iid.gp0)


## ----eval = FALSE--------------------------------------------------------
## A <- matrix(1, ncol = n, nrow = 1)
## e <- rep(0, 1)
## 
## inla( ... ~ ... + f(..., extraconstr = list(A, e), ...), ...)


## ------------------------------------------------------------------------
n <- nrow(nc.sids)
A <- matrix(1, ncol = n, nrow = 1)
e <- rep(0, 1)
m.pois.iid.extrac <- inla(SID74 ~ 
    f(ID, model = "iid", extraconstr = list(A = A, e = e)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.iid.extrac)


## ------------------------------------------------------------------------
airp.rw1.scale <- inla(log(AirPassengers) ~ 0 + year +
    f(ID, model = "rw1", scale.model = TRUE),
  data = airp.data)
summary(airp.rw1.scale)


## ----label = "scale-model", fig = TRUE, fig.width = 10, fig.height = 5, echo = FALSE, fig.cap = "Non-scaled versus scaled models. Point estimates (i.e., posterior means) of the random effects (left) and posterior marginal of the precision of the random effect (right)."----
par(mfrow = c(1, 2))

plot(airp.rw1$summary.random$ID[, "mean"],
  airp.rw1.scale$summary.random$ID[, "mean"], 
  xlab = "Non-scaled model", 
  ylab = "Scaled model", pch = 19)
abline(0, 1)

plot(airp.rw1$marginals.hyperpar[[2]], type = "l", xlim = c(0, 150),
  ylim = c(0, 0.9), ylab = "density", xlab = "precision")
lines(airp.rw1.scale$marginals.hyperpar[[2]], lty = 2)
legend("topright", c("Non-scaled model", "Scaled model"), lty = 1:2,
  bty = "n")


## ------------------------------------------------------------------------
airp.data$month.num <- as.numeric(airp.data$month)
airp.data$year.num <- as.numeric(airp.data$year)

airp.iid.ar1 <- inla(log(airp) ~ 0 +  f(year.num, model = "iid",
    group = month.num, control.group = list(model = "ar1", 
    scale.model = TRUE)),
  data = airp.data)

summary(airp.iid.ar1)


## ----label = "iid-ar1-grouped", fig = TRUE, echo = FALSE, fig.cap = "Grouped effects for the air passengers dataset. Solid lines represent the posterior means and the dashed lines a 95% credible intervals."----
par(mfrow = c(4, 3))
par(mar = c(3, 1.25, 1.5, 1.5))
#Table with summary of random effects; ID is for the YEAR
tab <-  airp.iid.ar1$summary.random$year.num
x.years <- 1949:1960

for(month in 1:12) {
  aux <- tab[(month-1) * 12 + 1:12, ]

  plot(x.years, aux[, "mean"], type = "l", xlab = "", ylab = "",
    main = paste0("Month ", month), ylim = c(4, 6.5), las = 2, cex.axis = 0.75)
  lines(x.years, aux[, "0.025quant"], lty = 2)
  lines(x.years, aux[, "0.975quant"], lty = 2)
}

