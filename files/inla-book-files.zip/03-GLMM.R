## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/03-GLMM-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## ----message = FALSE----------------------------------------------------------
library("spdep")
data(nc.sids)

# Overall rate
r <- sum(nc.sids$SID74) / sum(nc.sids$BIR74)
nc.sids$EXP74 <- r * nc.sids$BIR74

# Proportion of non-white births
nc.sids$NWPROP74 <- nc.sids$NWBIR74 / nc.sids$BIR74


## ----message = FALSE----------------------------------------------------------
m.pois.lin1 <- inla(SID74 ~ f(NWPROP74, model = "linear"),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.lin1)


## ----message = FALSE----------------------------------------------------------
library("INLA")
m.pois.clin1 <- inla(SID74 ~ f(NWPROP74, model = "clinear",
  range = c(0, Inf)), data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.clin1)


## -----------------------------------------------------------------------------
nc.sids$ID <- 1:100


## -----------------------------------------------------------------------------
m.pois.iid <- inla(SID74 ~ f(ID, model = "iid"),
  data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.iid)


## -----------------------------------------------------------------------------
m.pois.iid2 <- inla(SID74 ~ NWPROP74 + f(ID, model = "iid"),
  data = nc.sids, family = "poisson",
  E = EXP74)

summary(m.pois.iid2)


## -----------------------------------------------------------------------------
m.pois.z <- inla(SID74 ~ f(ID, model = "z", Z = Diagonal(nrow(nc.sids), 1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.z)


## -----------------------------------------------------------------------------
m.pois.g0 <- inla(SID74 ~ f(ID, model = "generic0", 
  Cmatrix = Diagonal(nrow(nc.sids), 1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.g0)


## -----------------------------------------------------------------------------
K1 <- Diagonal(nrow(nc.sids), 1)

m.pois.g2 <- inla(SID74 ~ f(ID, model = "generic3", Cmatrix = list(K1)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.g2)


## -----------------------------------------------------------------------------
#Overall rate
r79 <- sum(nc.sids$SID79) / sum(nc.sids$BIR79)
nc.sids$EXP79 <- r79 * nc.sids$BIR79


## -----------------------------------------------------------------------------
#New data.frame
nc.new <- data.frame(SID = c(nc.sids$SID74, nc.sids$SID79),
  EXP = c(nc.sids$EXP74, nc.sids$EXP79),
  PERIOD = as.factor(c(rep("74", 100), rep("79", 100))),
  ID = 1:200)


## -----------------------------------------------------------------------------
m.pois.iid2d <- inla(SID ~ 0 + PERIOD + f(ID, model = "iid2d", n = 2 * 100),
  data = nc.new, family = "poisson", E = EXP)

summary(m.pois.iid2d)


## ----label = "sids-iid2d", fig = TRUE, echo = FALSE, fig.cap = '(ref:sids-iid2d)', fig.height = 3.45, fig.width = 6----
#ggplot version
library("ggplot2")
tab <- data.frame(u = m.pois.iid2d$summary.random$ID$mean[1:100],
  v = m.pois.iid2d$summary.random$ID$mean[100 + 1:100])

ggplot(tab, aes (x = u, y = v)) + geom_point() +
  xlab(expression(u[i])) +
  ylab(expression(v[i])) +
  geom_abline(intercept = 0, slope = 1)


## -----------------------------------------------------------------------------
data(AirPassengers)

airp.data <- data.frame(airp = as.vector(AirPassengers),
  month = as.factor(rep(1:12, 12)), 
  year = as.factor(rep(1949:1960, each = 12)),
  ID = 1:length(AirPassengers))


## ----label = "airp", fig = TRUE, echo = FALSE, fig.cap = "Monthly international airline passengers: original data (top) and log-scale (bottom).", fig.width = 5, fig.height = 8, fig.align = "center"----
# ggplot version
library("ggfortify")
library("gridExtra")


p1 <- autoplot(AirPassengers) + 
  ggtitle("Number of international passengers") +
  xlab("Time") +
  ylab("AirPassengers")

p2 <- autoplot(log(AirPassengers)) + 
  ggtitle("Number of international passengers (log-scale)") +
  xlab("Time") +
  ylab("log(AirPassengers)")

grid.arrange(p1, p2, nrow = 2)


## -----------------------------------------------------------------------------
airp.rw1 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "rw1"),
  data = airp.data, control.predictor = list(compute = TRUE))
summary(airp.rw1)


## -----------------------------------------------------------------------------
airp.rw2 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "rw2"),
  data = airp.data, control.predictor = list(compute = TRUE))
summary(airp.rw2)



## ----eval = FALSE, label = "airp-rw2", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers."----
## plot(log(AirPassengers),
##   main = "Number of international passengers (log-scale)")
## lines(as.vector(time(AirPassengers)),
##   airp.rw1$summary.fitted.values$mean, lty = 2)
## lines(as.vector(time(AirPassengers)),
##   airp.rw2$summary.fitted.values$mean, lty = 3)
## 
## legend("topleft", legend = c("data", "RW1", "RW2"), lty = 1:3, bty = "n")


## ----label = "airp-rw", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers.", fig.height = 3.75, fig.width = 6----
# ggplot version

tab <- data.frame(x = rep(as.vector(time(AirPassengers)), 3),
  y = c(log(AirPassengers), airp.rw1$summary.fitted.values$mean,
    airp.rw2$summary.fitted.values$mean),
  lab = rep(c("data", "RW1", "RW2"), each = length(AirPassengers))
)

ggplot(tab, aes(x = x, y = y, linetype = lab)) + geom_line() +
  theme(legend.position = c(0.1, 0.8), legend.title = element_blank()) +
  xlab("Time") +
  ylab("log(AirPassengers)") +
  ggtitle("Number of international passengers (log-scale)")


## -----------------------------------------------------------------------------
airp.seasonal <- inla(log(AirPassengers) ~ 0 + year +
    f(ID, model = "seasonal", season.length = 12),
  data = airp.data)

summary(airp.seasonal)


## -----------------------------------------------------------------------------
airp.ar1 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "ar1"),
  data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar1)


## -----------------------------------------------------------------------------
airp.ar3 <- inla(log(AirPassengers) ~ 0 + year + f(ID, model = "ar",
  order = 3), data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar3)


## -----------------------------------------------------------------------------
Z <- model.matrix (~ 0 + year, data = airp.data)
Q.beta <- Diagonal(12, 0.001)

airp.ar1c <- inla(log(AirPassengers) ~ 1 + f(ID, model = "ar1c",
  args.ar1c = list(Z = Z, Q.beta = Q.beta)),
  data = airp.data, control.predictor = list(compute = TRUE))

summary(airp.ar1c)


## ----eval = FALSE, label = "airp-ar2", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers using autoregressive models."----
## plot(log(AirPassengers),
##   main = "Number of international passengers (log-scale)")
## lines(as.vector(time(AirPassengers)),
##   airp.ar1$summary.fitted.values$mean, lty = 2)
## lines(as.vector(time(AirPassengers)),
##   airp.ar3$summary.fitted.values$mean, lty = 3)
## lines(as.vector(time(AirPassengers)),
##   airp.ar1c$summary.fitted.values$mean, lty = 4)
## 
## legend("topleft", legend = c("data", "AR(1)", "AR(3)", "AR(1) with cov."),
##   lty = 1:4, bty = "n")


## ----label = "airp-ar", fig = TRUE, echo = FALSE, fig.cap = "Fitted values (i.e., posterior means) of the number of international passengers using autoregressive models.", fig.width = 6, fig.height = 3.975----
# ggplot version

tab <- data.frame(x = rep(as.vector(time(AirPassengers)), 4),
  y = c(log(AirPassengers), 
    airp.ar1$summary.fitted.values$mean,
    airp.ar3$summary.fitted.values$mean,
    airp.ar1c$summary.fitted.values$mean),
  lab = factor(rep(c("data", "AR(1)", "AR(3)", "AR(1) with cov."),
    each = length(AirPassengers)),
    levels = c("data", "AR(1)", "AR(3)", "AR(1) with cov."))
)

ggplot(tab, aes(x = x, y = y, linetype = lab)) + geom_line() +
  theme(legend.position = c(0.15, 0.8), legend.title = element_blank()) +
  xlab("Time") +
  ylab("log(AirPassengers)") +
  ggtitle("Number of international passengers (log-scale)")


## -----------------------------------------------------------------------------
names(inla.models()$latent$iid)


## -----------------------------------------------------------------------------
prec.prior <- inla.models()$latent$iid$hyper$theta
prec.prior


## ----eval = FALSE-------------------------------------------------------------
## hyper = list(prec = list(prior = "gaussian", param = c(0, 0.001)))


## -----------------------------------------------------------------------------
m.pois.iid.gp <- inla(SID74 ~ f(ID, model = "iid",
    hyper = list(theta = list(prior = "gaussian", param = c(0, 0.001)))),
  data = nc.sids, family = "poisson",
  E = EXP74)
summary(m.pois.iid.gp)


## ----eval = FALSE-------------------------------------------------------------
## hyper = list(theta = list(prior = "gaussian", param = c(0, 0.001)))


## ----eval = FALSE-------------------------------------------------------------
## hyper = list(theta1 = list(...), theta2 = list(...))


## -----------------------------------------------------------------------------
inla.models()$latent$rw1$constr


## -----------------------------------------------------------------------------
inla.models()$latent$iid$constr


## -----------------------------------------------------------------------------
m.pois.iid.gp0 <- inla(SID74 ~ f(ID, model = "iid", constr = TRUE),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.iid.gp0)


## ----eval = FALSE-------------------------------------------------------------
## A <- matrix(1, ncol = n, nrow = 1)
## e <- rep(0, 1)
## 
## inla( ... ~ ... + f(..., extraconstr = list(A, e), ...), ...)


## -----------------------------------------------------------------------------
n <- nrow(nc.sids)
A <- matrix(1, ncol = n, nrow = 1)
e <- rep(0, 1)
m.pois.iid.extrac <- inla(SID74 ~ 
    f(ID, model = "iid", extraconstr = list(A = A, e = e)),
  data = nc.sids, family = "poisson", E = EXP74)

summary(m.pois.iid.extrac)


## -----------------------------------------------------------------------------
airp.rw1.scale <- inla(log(AirPassengers) ~ 0 + year +
    f(ID, model = "rw1", scale.model = TRUE),
  data = airp.data)
summary(airp.rw1.scale)


## ----label = "scale-model", fig = TRUE, fig.width = 8, fig.height = 3.5, echo = FALSE, fig.cap = "Non-scaled versus scaled models. Point estimates (i.e., posterior means) of the random effects (left) and posterior marginal of the precision of the random effect (right)."----
# ggplot version

tab <- data.frame(nonscaled = airp.rw1$summary.random$ID[, "mean"],
  scaled = airp.rw1.scale$summary.random$ID[, "mean"])
p1 <- ggplot(tab, aes(x = nonscaled, y = scaled)) + geom_point() +
  xlab("Non-scaled model") +
  ylab("Scaled model") +
  geom_abline(intercept = 0, slope = 1)

tab <- data.frame(x = c(airp.rw1$marginals.hyperpar[[2]][, 1],
    airp.rw1.scale$marginals.hyperpar[[2]][, 1]),
  y = c(airp.rw1$marginals.hyperpar[[2]][, 2],
    airp.rw1.scale$marginals.hyperpar[[2]][, 2]),
  lab = rep(c("Non-scaled model", "Scaled model"), 
    c(nrow(airp.rw1$marginals.hyperpar[[2]]),
      nrow(airp.rw1.scale$marginals.hyperpar[[2]])))
)
p2 <- ggplot(tab, aes(x = x, y = y, linetype = lab)) + geom_line() +
  xlab("precision") +
  ylab("density") +
  theme(legend.position = c(0.75, 0.8), legend.title = element_blank())

grid.arrange(p1, p2, ncol = 2)


## -----------------------------------------------------------------------------
airp.data$month.num <- as.numeric(airp.data$month)
airp.data$year.num <- as.numeric(airp.data$year)

airp.iid.ar1 <- inla(log(airp) ~ 0 +  f(year.num, model = "iid",
    group = month.num, control.group = list(model = "ar1", 
    scale.model = TRUE)),
  data = airp.data)
summary(airp.iid.ar1)


## ----eval = FALSE, label = "iid-ar1-grouped2", fig = TRUE, echo = FALSE, fig.cap = "Grouped effects for the air passengers dataset. Solid lines represent the posterior means and the dashed lines 95% credible intervals."----
## par(mfrow = c(4, 3))
## par(mar = c(3, 1.5, 1.5, 1.5))
## #Table with summary of random effects; ID is for the YEAR
## tab <-  airp.iid.ar1$summary.random$year.num
## x.years <- 1949:1960
## 
## for(month in 1:12) {
##   aux <- tab[(month-1) * 12 + 1:12, ]
## 
##   plot(x.years, aux[, "mean"], type = "l", xlab = "", ylab = "",
##     main = paste0("Month ", month), ylim = c(4, 6.5), las = 2, cex.axis = 0.75)
##   lines(x.years, aux[, "0.025quant"], lty = 2)
##   lines(x.years, aux[, "0.975quant"], lty = 2)
## }


## ----eval = TRUE, label = "iid-ar1-grouped", fig = TRUE, echo = FALSE, fig.cap = "Grouped effects for the air passengers dataset. Solid lines represent the posterior means and the dashed lines 95% credible intervals."----

# ggplot version
#Table with summary of random effects; ID is for the YEAR
tab <-  airp.iid.ar1$summary.random$year.num
tab$year <- (1949:1960)[tab$ID]
tab$month <- factor(rep(paste("Month ", 1:12, sep = ""), each = 12),
  levels = paste("Month ", 1:12, sep = ""))

# Rename quantiles
names(tab)[c(4, 6)] <- c("q025", "q975")

ggplot(tab, aes(x = year, y = mean)) + geom_line() +
  facet_wrap(~ month, ncol = 3) +
  geom_line(aes(x = year, y = q025), linetype = 2) + 
  geom_line(aes(x = year, y = q975), linetype = 2) +
  theme(axis.title.x = element_blank(), axis.title.y = element_blank(),
    axis.text.x = element_text(angle = 90, size = 8)) +
  scale_x_continuous(breaks = seq(1949, 1960, 1))

