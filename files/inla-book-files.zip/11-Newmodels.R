## ----sett11, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/11-Newmodels-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## ----message = FALSE, results = 'hide', message = FALSE-----------------------
library("spdep")
library("rgdal")

SIDS <- readOGR(system.file("shapes/sids.shp", package="spData")[1])
proj4string(SIDS) <- CRS("+proj=longlat +ellps=clrk66")

#Expected cases
SIDS$EXP74 <- SIDS$BIR74 * sum(SIDS$SID74) / sum(SIDS$BIR74)
#Standardised Mortality Ratio
SIDS$SMR74 <- SIDS$SID74 / SIDS$EXP74
#Proportion of non-white births
SIDS$PNWB74 <- SIDS$NWBIR74 / SIDS$BIR74


## ----fig = TRUE, label = "sidssmr", fig.cap = "Standardised mortality ratio of the North Carolina SIDS dataset for the period 1971-1974.", echo = FALSE----
library("viridis")
spplot(SIDS, "SMR74", col.regions = rev(magma(16)))


## -----------------------------------------------------------------------------
#Adjacency matrix
adj <- poly2nb(SIDS)
W <- as(nb2mat(adj, style = "B"), "sparseMatrix")



## -----------------------------------------------------------------------------
e.values <- eigen(W)$values
rho.min <- min(e.values)
rho.max <- max(e.values)


## -----------------------------------------------------------------------------
#Re-scale adjacency matrix
W <- W / rho.max


## -----------------------------------------------------------------------------
interpret.theta <- function() {
  return(
    list(prec = exp(theta[1L]),
    rho = 1 / (1 + exp(-theta[2L])))
  )
}


## -----------------------------------------------------------------------------
graph <- function(){
  require(Matrix)

  return(Diagonal(nrow(W), x = 1) + W)
}


## -----------------------------------------------------------------------------
Q <- function() {
  require(Matrix)

  param <- interpret.theta()

  return(param$prec * (Diagonal(nrow(W), x = 1) - param$rho * W) )
}


## -----------------------------------------------------------------------------
mu = function()
{
  return(numeric(0))
}


## -----------------------------------------------------------------------------
log.norm.const <- function() {
  param <- interpret.theta()
  n <- nrow(W)

  Q <- param$prec * (Diagonal(nrow(W), x = 1) - param$rho * W)

  res <- n * (-0.5 * log(2 * pi)) +
    0.5 * Matrix::determinant(Q, logarithm = TRUE)

  return(res)
}


## -----------------------------------------------------------------------------
log.prior <- function() {
  param = interpret.theta()

  res <- dgamma(param$prec, 1, 5e-05, log = TRUE) + log(param$prec) +
      log(1) + log(param$rho) + log(1 - param$rho)

  return(res)
}


## -----------------------------------------------------------------------------
initial <- function() {
  return(rep(0, 0))
}


## -----------------------------------------------------------------------------
quit <- function() {
  return(invisible())
}


## -----------------------------------------------------------------------------
'inla.rgeneric.CAR.model' <- function(
  cmd = c("graph", "Q", "mu", "initial", "log.norm.const",
    "log.prior", "quit"),
  theta = NULL) {

  #Internal function
  interpret.theta <- function() {
    return(
      list(prec = exp(theta[1L]),
      rho = 1 / (1 + exp(-theta[2L])))
    )
  }

  graph <- function(){
    require(Matrix)

    return(Diagonal(nrow(W), x = 1) + W)
  }

  Q <- function() {
    require(Matrix)

    param <- interpret.theta()

    return(param$prec * (Diagonal(nrow(W), x = 1) - param$rho * W) )
  }

  mu <- function()
  {
    return(numeric(0))
  }

  log.norm.const <- function() {
    return(numeric(0))

  }

  log.prior <- function() {
    param = interpret.theta()

    res <- dgamma(param$prec, 1, 5e-05, log = TRUE) + log(param$prec) +
      log(1) + log(param$rho) + log(1 - param$rho) 

    return(res)
  }

  initial <- function() {
    return(c(0, 0))
  }

  quit <- function() {
    return(invisible())
  }

  res <- do.call(match.arg(cmd), args = list())
  return(res)
}


## ----message = FALSE----------------------------------------------------------
library("INLA")

CAR.model <- inla.rgeneric.define(inla.rgeneric.CAR.model, W = W)


## -----------------------------------------------------------------------------
SIDS$idx <- 1:nrow(SIDS)

f.car <- SID74 ~ 1 + f(idx, model = CAR.model)

m.car <- inla(f.car, data = as.data.frame(SIDS), family = "poisson",
  E = SIDS$EXP74)#, control.inla = list(tolerance = 1e-20, h = 1e-4))



## ----eval = FALSE, echo = FALSE-----------------------------------------------
## #Generic 1 model
## m.g1 <- inla(SID74 ~ 1 + f(idx, model = "generic1", Cmatrix = W),
##   data = as.data.frame(SIDS), family = "poisson", E = SIDS$EXP74)
## 
## #Compute marginal of rho
## marg.g1rho <- inla.tmarginal(function(x) { 1/(1 + exp(-x))},
##   m.g1$marginals.hyperpar[[2]])


## -----------------------------------------------------------------------------
summary(m.car)


## -----------------------------------------------------------------------------
marg.prec <- inla.tmarginal(exp, m.car$marginals.hyperpar[[1]])
marg.rho <- inla.tmarginal(function(x) { 1/(1 + exp(-x))},
  m.car$marginals.hyperpar[[2]])


## ----fig = TRUE, label = "CARparams", fig.cap = '(ref:CARparams)', echo = FALSE, fig.height = 3.45, fig.width = 6----
#ggplot version
library("ggplot2")
library("gridExtra")

p1 <- ggplot(as.data.frame(marg.prec), aes(x = x, y = y)) + geom_line() +
  ggtitle("Precision") +
  xlab(expression(tau)) +
  ylab(expression(paste(pi, "(", tau, " | ", bold(y), ")"))) 
  
p2 <- ggplot(as.data.frame(marg.rho), aes(x = x, y = y)) + geom_line() +
  ggtitle("Spatial autocorrelation") +
  xlab(expression(rho)) +
  ylab(expression(paste(pi, "(", rho, " | ", bold(y), ")")))

grid.arrange(p1, p2, ncol = 2)


## -----------------------------------------------------------------------------
inla.zmarginal(marg.prec, FALSE)
inla.zmarginal(marg.rho, FALSE)


## ----fig = TRUE, label = "sidscar", fig.cap = "Posterior means of the CAR random effects.", echo = TRUE----
SIDS$CAR <- m.car$summary.random$idx[, "mean"]
spplot(SIDS, "CAR",  col.regions = rev(inferno(16)))


## -----------------------------------------------------------------------------
car.inla <- function(formula, d, rho, W, ...) {

  #Create structure of precision matrix I - rho * W
  IrhoW <- Matrix::Diagonal(nrow(W), x = 1) - rho * W

  #Add CAR index
  d$CARidx <- 1:nrow(d)

  formula <- update(formula, . ~ . + f(CARidx, model = "generic0", 
            Cmatrix = IrhoW))
  res <- inla(formula, data = d, ..., control.compute = list(mlik = TRUE),
    control.inla = list(tolerance = 1e-20, h = 1e-4))

  #Update mlik
  logdet <- determinant(IrhoW)$modulus
  res$mlik <- res$mlik + logdet / 2

  return(res)
}


## -----------------------------------------------------------------------------
rho.val <- seq(0.5, 1, length.out = 100)


## -----------------------------------------------------------------------------
library("parallel")
options(mc.cores = 4)


## ----eval = FALSE-------------------------------------------------------------
## car.models <- mclapply (rho.val, function(rho) {
##     car.inla(SID74 ~ 1, as.data.frame(SIDS), rho, W,
##       family = "poisson", E = SIDS$EXP74,
##       num.threads = 1)
## })


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## save(file = "results/BMA.RData", list = "car.models")


## ----echo = FALSE-------------------------------------------------------------
load("results/BMA.RData")


## -----------------------------------------------------------------------------
library("INLABMA")
car.bma <- INLABMA(car.models, rho.val, log(1))


## -----------------------------------------------------------------------------
#Obtain log-marginal likelihoods
mliks <- unlist(lapply(car.models, function(X){X$mlik[1, 1]}))


## -----------------------------------------------------------------------------
# Fixed effects
car.bma$summary.fixed


## -----------------------------------------------------------------------------
fit.inla <- function(d, x){
  #Rho
  rho <- x

  res <- car.inla(SID74 ~ 1, d, rho, W,
    family = "poisson", E = d$EXP74)

  return(list(model.sim = res, mlik = res$mlik[1, 1]))
}


## -----------------------------------------------------------------------------
library("logitnorm")
#Sample values of rho
rq.rho <- function(x, sigma = 0.15) {
  rlogitnorm(1, mu = logit(x), sigma = sigma)
}

#Log-density of proposal distribution
dq.rho <- function(x, y, sigma = 0.15, log = TRUE) {
  dlogitnorm(y, mu = logit(x), sigma = sigma, log = log)
}


## -----------------------------------------------------------------------------
#Log-density of prior
prior.rho <- function(rho, log = TRUE) {
  return(dunif(rho, log = log))
}


## ----eval = FALSE-------------------------------------------------------------
## inlamh.res <- INLAMH(as.data.frame(SIDS), fit.inla, 0.95, rq.rho, dq.rho,
##   prior.rho,
##   n.sim = 100, n.burnin = 100, n.thin = 5, verbose = TRUE)


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## save(file = "results/CAR.RData", list = "inlamh.res")


## ----echo = FALSE-------------------------------------------------------------
load("results/CAR.RData")


## -----------------------------------------------------------------------------
rho.sim <- unlist(inlamh.res$b.sim)


## ----fig = TRUE, label = "INLAMH-rho", fig.cap = "Samples from the posterior distribuion (left) and kernel density estimate of the posterior marginal of the spatial autocorrelation parameter.", echo = FALSE, fig.width = 8, fig.height = 4.5----
# ggplot version

p1 <- ggplot(data.frame(iter = 1:length(rho.sim), rho.sim = rho.sim),
  aes (x = iter, y = rho.sim)) + geom_line() + 
  ggtitle(bquote(paste("Samples from posterior of ", rho))) +
  xlab("Iteration") +
  ylab(expression(rho))

p2 <- ggplot(as.data.frame(density(rho.sim, from = 0, to = 1)[c("x", "y")]), 
  aes(x = x, y = y)) + geom_line() +
  ggtitle(bquote(paste("Posterior marginal of ", rho))) +
  xlab(expression(rho)) +
  ylab("density")

grid.arrange(p1, p2, ncol = 2)


## -----------------------------------------------------------------------------
#Posterior mean
mean(rho.sim)
#Posterior st. dev.
sd(rho.sim)
#Quantiles
quantile(rho.sim)


## ----eval = FALSE, fig = TRUE, label = "comp2", fig.cap = "Comparison of posterior marginals of the spatial autocorrelation parameter obtained with three different methods.", echo = FALSE, results = "markup"----
## plot(car.bma$rho$marginal, type = "l", lty = 2, ylim = c(0, 8),
##   xlab = expression(rho), ylab = "Density")
## lines(marg.rho, lty = 1)
## lines(density(rho.sim, from = 0, to = 1), lty = 3)
## 
## legend("topleft", c("rgeneric", "BMA", "INLA w/ MCMC"),
##    lty = c(1, 2, 3), bty = "n")


## ----fig = TRUE, label = "comp", fig.cap = "Comparison of posterior marginals of the spatial autocorrelation parameter obtained with three different methods.", echo = FALSE, results = "markup", fig.height = 3.45, fig.width = 6----
# ggplot version


vals <- c("solid", "dashed", "dotted")
labs <- c("rgeneric", "BMA", "INLA w/ MCMC")
names(vals) <- vals
names(labs) <- vals

ggplot(as.data.frame(car.bma$rho$marginal), aes(x = x, y = y)) +
  geom_line(aes(linetype = "dashed")) +
  xlab(expression(rho)) +
  ylab("Density") +
  xlim(0.45, 1) +
  ylim(0, 8) +
  geom_line(data = as.data.frame(density(rho.sim, from = 0, to = 1)[c("x", "y")]), aes(x = x, y = y, linetype = "dotted")) +
  geom_line(data = as.data.frame(marg.rho), aes(x = x, y = y, linetype = "solid")) +
  scale_linetype_manual(#name = "Method",
    values = vals,
    labels = labs) +
  theme(legend.position = c(0.15, 0.8), legend.title = element_blank())

