# This code takes the original 77-precinct map to create a 75 precinct map

# Convertion is a follows:
# 121st precicnt is part of 120th precinct
# Precinct 22 is Central Park and has no population

library(rgdal)
library(maptools)
library(rgeos)

#Load data
nyc.precincts <- readOGR(".", "geo_export_6e1851ab-d036-443b-876e-bcbd703ff5d8")

slot(nyc.precincts, "polygons") <- lapply(slot(nyc.precincts, "polygons"), checkPolygonsHoles)

#Remove CEntral Park
nyc.precincts <- nyc.precincts[-which(nyc.precincts$precinct == 22), ]

# Fix some boundaries
# https://gis.stackexchange.com/questions/163445/getting-topologyexception-input-geom-1-is-invalid-which-is-due-to-self-intersec

nyc.precincts <- gBuffer(nyc.precincts, byid = TRUE, width = 0)

#Merge 121 to 120
idx <- nyc.precincts$precinct
idx [which(idx == 121)] <- 122

nyc.precincts <- unionSpatialPolygons(nyc.precincts, idx)

#Reorder data
nyc.precincts <- nyc.precincts[order(as.numeric(names(nyc.precincts))),  ]


# Add precinct
d <- data.frame(precinct = names(nyc.precincts))
rownames(d) <- d$precinct

nyc.precincts <- SpatialPolygonsDataFrame(nyc.precincts,d)

#Set IDs
for(i in 1:length(nyc.precincts)) {
  slot(nyc.precincts@polygons[[i]], "ID") <- as.character(nyc.precincts$precinct[i])
}
  
writeOGR(nyc.precincts, ".", "nyc_precincts",  driver="ESRI Shapefile")


