## ----sett05, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/05-Priors-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
names(inla.models()$latent$iid$hyper)
inla.models()$latent$iid$hyper$theta$name
inla.models()$latent$iid$hyper$theta$short.name


## -----------------------------------------------------------------------------
inla.models()$latent$iid$hyper$theta


## -----------------------------------------------------------------------------
prec.prior <- list(prec = list(prior = "loggamma", param = c(0.01, 0.01)),
  initial = 4, fixed = FALSE)


## -----------------------------------------------------------------------------
f <- y ~ 1 + f(idx, model = "iid", hyper = prec.prior)


## -----------------------------------------------------------------------------
names(inla.models()$prior)


## -----------------------------------------------------------------------------
theta <- seq(-100, 100, by = 0.1)
log_dens <- dnorm(theta, 0, sqrt(1 / 0.001), log = TRUE)

gaus.prior <- paste0("table: ", 
  paste(c(theta, log_dens), collapse = " ")
)


## -----------------------------------------------------------------------------
substr(gaus.prior, 1, 50)


## -----------------------------------------------------------------------------
substr(gaus.prior, nchar(gaus.prior) - 50 + 1, nchar(gaus.prior))


## ----results = "hide"---------------------------------------------------------
"expression:
  mean = 0;
  prec = 1000;
  logdens = 0.5 * log(prec) - 0.5 * log (2 * pi);
  logdens = logdens - 0.5 * prec * (theta - mean)^2;
  return(logdens);
"


## -----------------------------------------------------------------------------
HN.prior = "expression:
  tau0 = 0.001;
  sigma = exp(-theta/2);
  log_dens = log(2) - 0.5 * log(2 * pi) + 0.5 * log(tau0);
  log_dens = log_dens - 0.5 * tau0 * sigma^2;
  log_dens = log_dens - log(2) - theta / 2;
  return(log_dens);  
"


## -----------------------------------------------------------------------------
HC.prior  = "expression:
  sigma = exp(-theta/2);
  gamma = 25;
  log_dens = log(2) - log(pi) - log(gamma);
  log_dens = log_dens - log(1 + (sigma / gamma)^2);
  log_dens = log_dens - log(2) - theta / 2;
  return(log_dens);
"


## -----------------------------------------------------------------------------
HT.prior = "expression:
  sigma = exp(-theta/2);
  nu = 3;
  log_dens = 0 - 0.5 * log(nu * pi) - (-0.1207822);
  log_dens = log_dens - 0.5 * (nu + 1) * log(1 + sigma * sigma);
  log_dens = log_dens - log(2) - theta / 2;
  return(log_dens);
"


## -----------------------------------------------------------------------------
UN.prior = "expression:
  log_dens = 0 - log(2) - theta / 2;
  return(log_dens);
"


## ----label = "pcprior", echo = FALSE, fig = TRUE, fig.width = 8, fig.height = 4, fig.cap = '(ref:pcprior)'----

prec <- seq(0.01, 2, by = 0.01)

alpha <- c(0.95, 0.90, 0.80, 0.50, 0.25, 0.1)
pc.prec <- lapply(alpha, function(a) {
  inla.pc.dprec(prec, 1, a)
})
pc.prec <- do.call(c, pc.prec)

tab <- data.frame(prec = rep(prec, length(alpha)), pc.prec = pc.prec,
  alpha = rep(as.character(alpha), each = length(prec)))

library("ggplot2")
ggplot(tab, aes(x = prec, y = pc.prec, linetype = alpha)) + geom_line() +
  xlab(expression(paste("precision ", tau))) +
  ylab("density") +
  ggtitle(expression(paste("PC prior on the precision ", tau,
    " with P(", sigma, " > 1) = ", alpha))) +
  scale_linetype_discrete(name = expression(alpha))



## -----------------------------------------------------------------------------
csize_data <- read.csv (file = "data/class_size_data.txt", header = FALSE,
  sep = "", dec = ".")

#Set names
names(csize_data) <- c("clsnr", "pupil", "nlitpre", "nmatpre", "nlitpost",
  "nmatpost", "csize")

#Set NA's
csize_data [csize_data < -1e+29 ] <- NA

#Set class size levels
csize_data$csize <- as.factor(csize_data$csize)
levels(csize_data$csize) <- c("<=19", "20-24", "25-29", ">=30")


## -----------------------------------------------------------------------------
prior.list = list(
  default = list(prec = list(prior = "loggamma", param = c(1, 0.00005))),
  half.normal = list(prec = list(prior = HN.prior)),
  half.cauchy = list(prec = list(prior = HC.prior)),
  h.t = list(prec = list(prior = HT.prior)),
  uniform = list(prec = list(prior = UN.prior)),
  pc.prec = list(prec = list(prior = "pc.prec", param = c(5, 0.01)))
) 


## -----------------------------------------------------------------------------
#Remove rows with NA's
csize_data2 <- na.omit(csize_data[, -5])


## -----------------------------------------------------------------------------
csize.models <- lapply(prior.list, function(tau.prior) {
  inla(nmatpost ~ 1 + nmatpre + nlitpre + csize +
      f(clsnr, model = "iid", hyper = tau.prior), data = csize_data2,
    control.family = list(hyper = tau.prior))
})



## ----label = "sensitivity", fig = TRUE, echo = FALSE, fig.cap = "Sensitivity analysis on the priors of the precisions of the model.", fig.height = 3.45, fig.width = 6----
#ggplot version
library("gridExtra")
vars <- c(expression(tau[e]), expression(tau[u]))

p <- lapply(1:2, function(i) {

  aux <- ggplot(as.data.frame(csize.models[[1]]$marginals.hyperpar[[i]]),
    aes(x = x, y = y)) + geom_line() + xlab(vars[i])  + ylab("density")
  for(j in 1:length(csize.models)) {
    aux <- aux + geom_line(data = as.data.frame(csize.models[[j]]$marginals.hyperpar[[i]]), aes(x = x, y = y), linetype = j + 1)
  }

  return(aux)
})

grid.arrange(p[[1]], p[[2]], ncol = 2)


## -----------------------------------------------------------------------------
library("SemiPar")
data(lidar)

#Data for prediction
xx <- seq(390, 720, by = 5)
# Add data for prediction
new.data <- cbind(range = xx, logratio = NA)
new.data <- rbind(lidar, new.data)

# Set prior on precision
prec.prior <- list(prec = list(param = c(0.001, 0.001)))

#RW1 latent effect
m.rw1 <- inla(logratio ~ 1 + f(range, model = "rw1", constr = FALSE,
    hyper = prec.prior),
  data = new.data, control.predictor = list(compute = TRUE))
#RW1 scaled latent effect
m.rw1.sc <- inla(logratio ~ 1 + f(range, model = "rw1", constr = FALSE,
    scale.model = TRUE, hyper = prec.prior),
  data = new.data, control.predictor = list(compute = TRUE))

#RW2 latent effect
m.rw2 <- inla(logratio ~ 1 + f(range, model = "rw2", constr = FALSE,
    hyper = prec.prior),
  data = new.data, control.predictor = list(compute = TRUE))
#RW2 scaled latent effect
m.rw2.sc <- inla(logratio ~ 1 + f(range, model = "rw2", constr = FALSE,
    scale.model = TRUE,  hyper = prec.prior),
  data = new.data, control.predictor = list(compute = TRUE))



## ----echo = FALSE, results = "asis"-------------------------------------------
tab <- rbind(
  m.rw1$summary.hyperpar[2,],
  m.rw1.sc$summary.hyperpar[2,],
  m.rw2$summary.hyperpar[2,],
  m.rw2.sc$summary.hyperpar[2,]
)

tab <- cbind(Model = c("`rw1`", "`rw1`", "`rw2`", "`rw2`"),
  Scaled = c("No", "Yes", "No", "Yes"),
  round(tab, 2))

names(tab) <- c("Model", "Scaled", "Mean", "St. dev.", 
   "0.025 quant.", "0.5 quant.", "0.975 quant.", "Mode")

knitr::kable(tab[, c(1:5, 7)], booktabs = TRUE, row.names = FALSE,
  format = "markdown",
  escape = FALSE,
  caption = "Table: (\\#tab:lidarscaling)Summary of the posterior distribution of the precision hyperparameters for different scaled and un-scaled intrinsic latent effects.")

  cat("\nTable: (\\#tab:lidarscaling)Summary of the posterior distribution of the precision hyperparameters for different scaled and un-scaled intrinsic latent effects.\n")


## ----label = "lidarscaling", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarscaling)'----

tab <- data.frame(range = rep(xx, 4),
  model = rep(c("rw1", "rw2"), each = 2 * length(xx)),
  scaled = rep(c("No", "Yes", "No", "Yes"), each = length(xx)),
  logratio = c(m.rw1$summary.fitted[-c(1:nrow(lidar)), "mean"],
    m.rw1.sc$summary.fitted[-c(1:nrow(lidar)), "mean"],
    m.rw2$summary.fitted[-c(1:nrow(lidar)), "mean"],
    m.rw2.sc$summary.fitted[-c(1:nrow(lidar)), "mean"])
)

ggplot(aes(x = range, y = logratio), data = lidar) + geom_point() +
  ggtitle("LIDAR data") +
  geom_line(aes(x = range, y = logratio, linetype = model, colour = scaled),
    data = tab)

