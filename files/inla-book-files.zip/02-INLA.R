## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library(knitr)
opts_chunk$set(
  fig.path = 'figs/02-INLA-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## ----label = "gridccd", fig = TRUE, echo = FALSE, fig.cap = '(ref:gridccd)'----
knitr::include_graphics("graphics/gridccd.pdf")


## ----eval = FALSE--------------------------------------------------------
## # Set INLA repository
## options(repos = c(getOption("repos"),
##    INLA="https://inla.r-inla-download.org/R/stable"))
## 
## # Install INLA and dependencies (from CRAN)
## install.packages("INLA", dep = TRUE)


## ------------------------------------------------------------------------
library(MASS)
summary(cement)


## ------------------------------------------------------------------------
library("INLA")
m1 <- inla(y ~ x1 + x2 + x3 + x4, data = cement)
summary(m1)


## ----eval = FALSE--------------------------------------------------------
## names(inla.models()$likelihood)


## ----message = FALSE-----------------------------------------------------
library(spdep)
data(nc.sids)

# Overall rate
r <- sum(nc.sids$SID74) / sum(nc.sids$BIR74)

# Expected SIDS per county
nc.sids$EXP74 <- r * nc.sids$BIR74


## ------------------------------------------------------------------------
# Proportion of non-white births
nc.sids$NWPROP74 <- nc.sids$NWBIR74 / nc.sids$BIR74


## ------------------------------------------------------------------------
m.pois <- inla(SID74 ~ NWPROP74, data = nc.sids, family = "poisson",
  E = EXP74)
summary(m.pois)


## ------------------------------------------------------------------------
m.poisover <- inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
  data = nc.sids, family = "poisson", E = EXP74)


## ----eval = FALSE--------------------------------------------------------
## # Add index for latent effect
## nc.sids$idx <- 1:nrow(nc.sids)
## # Model fitting
## m.poisover <- inla(SID74 ~ NWPROP74 + f(idx, model = "iid"),
##   data = nc.sids, family = "poisson", E = EXP74)


## ------------------------------------------------------------------------
summary(m.poisover)


## ------------------------------------------------------------------------
# Poisson model
m.pois <- inla(SID74 ~ NWPROP74, data = nc.sids, family = "poisson",
  E = EXP74, control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))

# Poisson model with iid random effects
m.poisover <- inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
  data = nc.sids, family = "poisson", E = EXP74,
  control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))


## ----label = "nc-sids-IC", echo = FALSE----------------------------------
d <- data.frame(Model = c("Poisson", "Poisson + r. eff."),
  DIC = c(m.pois$dic$dic, m.poisover$dic$dic),
  WAIC = c(m.pois$waic$waic, m.poisover$waic$waic),
  CPO = c(-sum(log(m.pois$cpo$cpo)), -sum(log(m.poisover$cpo$cpo))),
  MLIK = c(m.pois$mlik[1, 1], m.poisover$mlik[1, 1])
)

knitr::kable(d, booktabs = TRUE,
  caption = "Summary of values of DIC, WAIC, CPO and marginal likelihood for different models
fit to the North Carolina SIDS data.")


## ----fig = TRUE, echo = FALSE, eval = TRUE, label = "nc-sids-CPO", fig.cap = "Values of CPOs and PITs computed for the models fit to the North Carolina SIDS data.", fig.width = 8, fig.height = 5----

par(mfrow = c(1, 2))

plot(m.pois$cpo$cpo, main = "CPO", pch = 2, xlab = "County",
  ylab = "Value")
points(m.poisover$cpo$cpo, pch = 3)
legend("top", legend = c("Poisson", "Poisson + r.eff."), pch = 2:3,
  bty = "n", cex = 0.8)

plot(m.pois$cpo$pit, main = "PIT", pch = 2, ylim = c(0, 1.2),
  xlab = "County", ylab = "Value")
points(m.poisover$cpo$pit, pch = 3)
legend("top", legend = c("Poisson", "Poisson + r.eff."), pch = 2:3,
  bty = "n", cex = 0.8)


## ------------------------------------------------------------------------
m.strategy <- lapply(c("gaussian", "simplified.laplace", "laplace"), 
  function(st) {
    return(lapply(c("ccd", "grid", "eb"), function(int.st) {
      inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
        data = nc.sids, family = "poisson", E = EXP74,
        control.inla = list(strategy = st, int.strategy = int.st),
        control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))
    }))
})


## ----echo = FALSE, fig = TRUE, label = "stintercept", fig.cap = '(ref:stintercept)', fig.height = 4, fitg.height = 6----
# Colors using the viridis palette
library(viridis)
intst.colors <- magma(4) #4 to remove yellow

plot(1, 1, type = "n", xlim = c(-1.2, -0.2), ylim = c(0, 5),
  xlab = expression(beta[0]),
  ylab = expression(paste(pi, "(", beta[0], " | ", bold(y), ")")) )
for(i in 1:3) {
  for(j in 1:3) {
    lines(m.strategy[[i]][[j]]$marginals.fixed[[1]], lty = i,
      col = intst.colors[j], lwd = 2)
  }
}
legend("topright", legend = c("gaussian", "simplified.laplace", "laplace"),
  lty = 1:3, bty = "n")
legend("right", legend = c("ccd", "grid", "eb"),
  col = intst.colors, lty = 1, bty = "n", lwd = 2)



## ----echo = FALSE, fig = TRUE, label = "stfixed", fig.cap = '(ref:stfixed)', fig.height = 4, fitg.height = 6----

plot(1, 1, type = "n", xlim = c(0.75, 3), ylim = c(0, 2),
  xlab = expression(beta[1]),
  ylab = expression(paste(pi, "(", beta[1], " | ", bold(y), ")")) )
for(i in 1:3) {
  for(j in 1:3) {
    lines(m.strategy[[i]][[j]]$marginals.fixed[[2]], lty = i,
      col = intst.colors[j], lwd = 2)
  }
}
legend("topright", legend = c("gaussian", "simplified.laplace", "laplace"),
  lty = 1:3, bty = "n")
legend("right", legend = c("ccd", "grid", "eb"),
  col = intst.colors, lty = 1, bty = "n", lwd = 2)



## ----echo = FALSE, fig = TRUE, label = "stprec", fig.cap = '(ref:stprec)', fig.height = 4, fitg.height = 6----

plot(1, 1, type = "n", xlim = c(0, 200), ylim = c(0, 0.035),
  xlab = expression(tau[u]),
  ylab = expression(paste(pi, "(", tau[u], " | ", bold(y), ")")) )

for(i in 1:3) {
  for(j in 1:3) {
    lines(m.strategy[[i]][[j]]$marginals.hyperpar[[1]], lty = i, 
      col = intst.colors[j], lwd = 2)
  }
}
legend("topright", legend = c("gaussian", "simplified.laplace", "laplace"),
  lty = 1:3, bty = "n")
legend("right", legend = c("ccd", "grid", "eb"),
  col = intst.colors, lty = 1, bty = "n", lwd = 2)


## ----label = "postmargs", fig = TRUE, fig.cap = '(ref:postmargs)'--------
library(ggplot2)
library(gridExtra)

# Posterior of coefficient of x1
plot1 <- ggplot(as.data.frame(m1$marginals.fixed$x1)) + 
  geom_line(aes(x = x, y = y)) +
  ylab (expression(paste(pi, "(", "x", " | ", bold(y), ")")))

# Posterior of precision
plot2 <- ggplot(as.data.frame(m1$marginals.hyperpar[[1]])) + 
  geom_line(aes(x = x, y = y)) +
  ylab (expression(paste(pi, "(", tau, " | ", bold(y), ")")))

grid.arrange(plot1, plot2, nrow = 2)


## ------------------------------------------------------------------------
1 - inla.pmarginal(0, m1$marginals.fixed$x1)


## ------------------------------------------------------------------------
inla.hpdmarginal(0.95, m1$marginals.hyperpar[[1]])


## ------------------------------------------------------------------------
marg.stdev <- inla.tmarginal(function(tau) tau^(-1/2),
  m1$marginals.hyperpar[[1]])


## ----label = "pmstdev", fig = TRUE, echo = FALSE, fig.cap = '(ref:pmstdev)'----
ggplot(as.data.frame(marg.stdev)) +
  geom_line(aes(x = x, y = y)) + 
  xlab(expression(sigma)) +
  ylab(expression(paste(pi, "(", sigma, " | ", bold(y), ")")))


## ------------------------------------------------------------------------
inla.zmarginal(marg.stdev)


## ------------------------------------------------------------------------
inla.emarginal(function(sigma) sigma, marg.stdev)


## ------------------------------------------------------------------------
inla.mmarginal(marg.stdev)


## ------------------------------------------------------------------------
# Fit model with config = TRUE
m1 <- inla(y ~ x1 + x2 + x3 + x4, data = cement,
  control.compute = list(config = TRUE))


## ------------------------------------------------------------------------
m1.samp <- inla.posterior.sample(100, m1, selection = list(x1 = 1, x2 = 1))


## ------------------------------------------------------------------------
names(m1.samp[[1]])


## ------------------------------------------------------------------------
m1.samp[[1]]


## ------------------------------------------------------------------------
x1x2.samp <- inla.posterior.sample.eval(function(...) {x1 * x2},
   m1.samp)


## ------------------------------------------------------------------------
summary(as.vector(x1x2.samp))


## ------------------------------------------------------------------------
# Sample hyperpars from joint posterior
set.seed(123)
prec.samp <- inla.hyperpar.sample(1000, m1)


## ----fig = TRUE, label = "hypsamp", echo = FALSE, fig.cap = '(ref:hypsamp)'----
hist(as.vector(prec.samp[, 1]), freq = FALSE, 
  ylab = expression(paste(pi, "(", tau, " | ", bold(y), ")")),
  xlab = expression(tau), main = NULL, breaks = 20)
lines(m1$marginals.hyperpar[[1]])

