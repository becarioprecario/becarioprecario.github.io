## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/02-INLA-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## ----label = "gridccd", fig = TRUE, echo = FALSE, fig.cap = '(ref:gridccd)'----
knitr::include_graphics("graphics/gridccd.pdf")


## ----eval = FALSE-------------------------------------------------------------
## # Set INLA repository
## options(repos = c(getOption("repos"),
##    INLA="https://inla.r-inla-download.org/R/stable"))
## 
## # Install INLA and dependencies (from CRAN)
## install.packages("INLA", dep = TRUE)


## -----------------------------------------------------------------------------
library("MASS")
summary(cement)


## -----------------------------------------------------------------------------
library("INLA")
m1 <- inla(y ~ x1 + x2 + x3 + x4, data = cement)
summary(m1)


## ----eval = FALSE-------------------------------------------------------------
## names(inla.models()$likelihood)


## ----message = FALSE----------------------------------------------------------
library("spdep")
data(nc.sids)

# Overall rate
r <- sum(nc.sids$SID74) / sum(nc.sids$BIR74)

# Expected SIDS per county
nc.sids$EXP74 <- r * nc.sids$BIR74


## -----------------------------------------------------------------------------
# Proportion of non-white births
nc.sids$NWPROP74 <- nc.sids$NWBIR74 / nc.sids$BIR74


## -----------------------------------------------------------------------------
m.pois <- inla(SID74 ~ NWPROP74, data = nc.sids, family = "poisson",
  E = EXP74)
summary(m.pois)


## -----------------------------------------------------------------------------
m.poisover <- inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
  data = nc.sids, family = "poisson", E = EXP74)


## ----eval = FALSE-------------------------------------------------------------
## # Add index for latent effect
## nc.sids$idx <- 1:nrow(nc.sids)
## # Model fitting
## m.poisover <- inla(SID74 ~ NWPROP74 + f(idx, model = "iid"),
##   data = nc.sids, family = "poisson", E = EXP74)


## -----------------------------------------------------------------------------
summary(m.poisover)


## -----------------------------------------------------------------------------
# Poisson model
m.pois <- inla(SID74 ~ NWPROP74, data = nc.sids, family = "poisson",
  E = EXP74, control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))

# Poisson model with iid random effects
m.poisover <- inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
  data = nc.sids, family = "poisson", E = EXP74,
  control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))


## ----label = "nc-sids-IC", echo = FALSE---------------------------------------
d <- data.frame(Model = c("Poisson", "Poisson + r. eff."),
  DIC = c(m.pois$dic$dic, m.poisover$dic$dic),
  WAIC = c(m.pois$waic$waic, m.poisover$waic$waic),
  CPO = c(-sum(log(m.pois$cpo$cpo)), -sum(log(m.poisover$cpo$cpo))),
  MLIK = c(m.pois$mlik[1, 1], m.poisover$mlik[1, 1])
)

knitr::kable(d, booktabs = TRUE,
  caption = "Summary of values of DIC, WAIC, CPO and marginal likelihood for different models
fit to the North Carolina SIDS data.")


## ----fig = TRUE, echo = FALSE, eval = TRUE, label = "nc-sids-CPO", fig.cap = "Values of CPOs and PITs computed for the models fit to the North Carolina SIDS data.", fig.width = 8, fig.height = 4.75----

# ggplot version
library("ggplot2")
library("gridExtra")

tab <- data.frame(county = rep(1:100, 2), 
  cpo = c(m.pois$cpo$cpo, m.poisover$cpo$cpo),
  pit = c(m.pois$cpo$pit, m.poisover$cpo$pit))
tab$model <- rep(c("Poisson", "Poisson + r.eff."), each = 100)

# CPO
p1 <- ggplot(tab, aes(x = county, y = cpo, shape = model)) +
  geom_point() +
  scale_shape_manual(values = c(2, 3)) +
  theme(legend.position = c(0.2, 0.9), legend.title = element_blank(),
    legend.background = element_rect(fill = "transparent")) +
  ggtitle("CPO") +
  xlab("County") + ylab("Value")

# PIT
p2 <- ggplot(tab, aes(x = county, y = pit, shape = model)) +
  geom_point() +
  scale_shape_manual(values = c(2, 3)) +
  theme(legend.position = c(0.2, 0.9), legend.title = element_blank(),
    legend.background = element_rect(fill = "transparent")) +
  ggtitle("PIT") +
  xlab("County") + ylab("Value") +
  ylim(0, 1.2)

grid.arrange(p1, p2, ncol = 2)


## -----------------------------------------------------------------------------
m.strategy <- lapply(c("gaussian", "simplified.laplace", "laplace"), 
  function(st) {
    return(lapply(c("ccd", "grid", "eb"), function(int.st) {
      inla(SID74 ~ NWPROP74 + f(CNTY.ID, model = "iid"),
        data = nc.sids, family = "poisson", E = EXP74,
        control.inla = list(strategy = st, int.strategy = int.st),
        control.compute = list(cpo = TRUE, dic = TRUE, waic = TRUE))
    }))
})


## ----echo = FALSE, fig = TRUE, label = "stintercept", fig.cap = '(ref:stintercept)', fig.height = 3.45, fitg.height = 6----
# Colors using the viridis palette
library("viridis")
intst.colors <- magma(4) #4 to remove yellow

# ggplot version

marg.beta <- lapply(m.strategy, function(X) {
  do.call(rbind, lapply(X, function(Y) {Y$marginals.fixed[[1]]}))
})
marg.beta <- as.data.frame(do.call(rbind, marg.beta))
marg.beta$strategy <- rep(c("gaussian", "simplified.laplace", "laplace"),
  each = 3 * 75)
marg.beta$strategy <- factor(marg.beta$strategy,
  levels = c("gaussian", "simplified.laplace", "laplace"))
marg.beta$int.strategy <- rep(rep( c("ccd", "grid", "eb"), each = 75), 3)
marg.beta$int.strategy <- factor(marg.beta$int.strategy,
  levels = c("ccd", "grid", "eb"))


ggplot(marg.beta, aes(x = x, y = y, linetype = strategy, 
    colour = int.strategy)) +
  geom_line() +
  xlim(-1.2, -0.2) + ylim(0, 5) +
  xlab(expression(beta[0])) +
  ylab(expression(paste(pi, "(", beta[0], " | ", bold(y), ")")) ) +
  scale_linetype_manual(values = c("solid", "dashed", "dotted")) +
  scale_colour_manual(values = intst.colors) +
  theme(legend.position = c(0.15, 0.65),
    legend.background = element_rect(fill = "transparent"),
    legend.title = element_blank())


## ----echo = FALSE, fig = TRUE, label = "stfixed", fig.cap = '(ref:stfixed)', fig.height = 3.45, fitg.height = 6----
# ggplot version


marg.beta <- lapply(m.strategy, function(X) {
  do.call(rbind, lapply(X, function(Y) {Y$marginals.fixed[[2]]}))
})
marg.beta <- as.data.frame(do.call(rbind, marg.beta))
marg.beta$strategy <- rep(c("gaussian", "simplified.laplace", "laplace"),
  each = 3 * 75)
marg.beta$strategy <- factor(marg.beta$strategy,
  levels = c("gaussian", "simplified.laplace", "laplace"))
marg.beta$int.strategy <- rep(rep( c("ccd", "grid", "eb"), each = 75), 3)
marg.beta$int.strategy <- factor(marg.beta$int.strategy,
  levels = c("ccd", "grid", "eb"))


ggplot(marg.beta, aes(x = x, y = y, linetype = strategy, 
    colour = int.strategy)) +
  geom_line() +
  xlim(0.75, 3) + ylim(0, 2) +
  xlab(expression(beta[1])) +
  ylab(expression(paste(pi, "(", beta[1], " | ", bold(y), ")")) ) +
  scale_linetype_manual(values = c("solid", "dashed", "dotted")) +
  scale_colour_manual(values = intst.colors) +
  theme(legend.position = c(0.15, 0.65), 
    legend.background = element_rect(fill = "transparent"), 
    legend.title = element_blank())


## ----echo = FALSE, fig = TRUE, label = "stprec", fig.cap = '(ref:stprec)', fig.height = 3.45, fitg.height = 6----

marg.prec <- lapply(m.strategy, function(X) {
  do.call(rbind, lapply(X, function(Y) {Y$marginals.hyperpar[[1]]}))
})
marg.prec <- as.data.frame(do.call(rbind, marg.prec))
marg.prec$strategy <- rep(c("gaussian", "simplified.laplace", "laplace"),
  each = 3 * 75)
marg.prec$strategy <- factor(marg.prec$strategy,
  levels = c("gaussian", "simplified.laplace", "laplace"))
marg.prec$int.strategy <- rep(rep( c("ccd", "grid", "eb"), each = 75), 3)
marg.prec$int.strategy <- factor(marg.prec$int.strategy,
  levels = c("ccd", "grid", "eb"))


ggplot(marg.prec, aes(x = x, y = y, linetype = strategy,
    colour = int.strategy)) +
  geom_line() +
  xlim(0, 200) + ylim(0, 0.035) +
  xlab(expression(tau[u])) +
  ylab(expression(paste(pi, "(", tau[u], " | ", bold(y), ")")) ) +
  scale_linetype_manual(values = c("solid", "dashed", "dotted")) +
  scale_colour_manual(values = intst.colors) +
  theme(legend.position = c(0.8, 0.65),
    legend.background = element_rect(fill = "transparent"),
    legend.title = element_blank())


## ----label = "postmargs", fig = TRUE, fig.cap = '(ref:postmargs)'-------------
library("ggplot2")
library("gridExtra")

# Posterior of coefficient of x1
plot1 <- ggplot(as.data.frame(m1$marginals.fixed$x1)) + 
  geom_line(aes(x = x, y = y)) +
  ylab (expression(paste(pi, "(", "x", " | ", bold(y), ")")))

# Posterior of precision
plot2 <- ggplot(as.data.frame(m1$marginals.hyperpar[[1]])) + 
  geom_line(aes(x = x, y = y)) +
  ylab (expression(paste(pi, "(", tau, " | ", bold(y), ")")))

grid.arrange(plot1, plot2, nrow = 2)


## -----------------------------------------------------------------------------
1 - inla.pmarginal(0, m1$marginals.fixed$x1)


## -----------------------------------------------------------------------------
inla.hpdmarginal(0.95, m1$marginals.hyperpar[[1]])


## -----------------------------------------------------------------------------
marg.stdev <- inla.tmarginal(function(tau) tau^(-1/2),
  m1$marginals.hyperpar[[1]])


## ----label = "pmstdev", fig = TRUE, echo = FALSE, fig.cap = '(ref:pmstdev)'----
ggplot(as.data.frame(marg.stdev)) +
  geom_line(aes(x = x, y = y)) + 
  xlab(expression(sigma)) +
  ylab(expression(paste(pi, "(", sigma, " | ", bold(y), ")")))


## -----------------------------------------------------------------------------
inla.zmarginal(marg.stdev)


## -----------------------------------------------------------------------------
inla.emarginal(function(sigma) sigma, marg.stdev)


## -----------------------------------------------------------------------------
inla.mmarginal(marg.stdev)


## -----------------------------------------------------------------------------
# Fit model with config = TRUE
m1 <- inla(y ~ x1 + x2 + x3 + x4, data = cement,
  control.compute = list(config = TRUE))


## -----------------------------------------------------------------------------
m1.samp <- inla.posterior.sample(100, m1, selection = list(x1 = 1, x2 = 1))


## -----------------------------------------------------------------------------
names(m1.samp[[1]])


## -----------------------------------------------------------------------------
m1.samp[[1]]


## -----------------------------------------------------------------------------
x1x2.samp <- inla.posterior.sample.eval(function(...) {x1 * x2},
   m1.samp)


## -----------------------------------------------------------------------------
summary(as.vector(x1x2.samp))


## -----------------------------------------------------------------------------
# Sample hyperpars from joint posterior
set.seed(123)
prec.samp <- inla.hyperpar.sample(1000, m1)


## ----eval = FALSE, fig = TRUE, label = "hypsamp2", echo = FALSE, fig.cap = '(ref:hypsamp)'----
## hist(as.vector(prec.samp[, 1]), freq = FALSE,
##   ylab = expression(paste(pi, "(", tau, " | ", bold(y), ")")),
##   xlab = expression(tau), main = NULL, breaks = 20)
## lines(m1$marginals.hyperpar[[1]])


## ----fig = TRUE, label = "hypsamp", echo = FALSE, fig.cap = '(ref:hypsamp)', fig.height = 3.5, fig.width = 6----
# ggplot version

tab <- data.frame(prec = prec.samp[, 1])
ggplot(tab, aes(x = prec)) +
  geom_histogram(aes(y=..density..), bins = 18) +
  geom_line(data = as.data.frame(m1$marginals.hyperpar[[1]]),
    aes(x = x, y = y)) + 
  xlab(expression(tau)) +
  ylab(expression(paste(pi, "(", tau, " | ", bold(y), ")"))) +
  xlim(0, 0.8)

