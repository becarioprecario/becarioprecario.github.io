## ----sett12, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/12-Missing-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
library("mice")
data(fdgs)
summary(fdgs)


## ----eval = TRUE, echo = TRUE-------------------------------------------------
# Subset for speed-up and testing
# Subsect 1, observations with NA's
subset1 <- which(is.na(fdgs$wgt) | is.na(fdgs$hgt))

#Subset 2, random sample of 500 individuals
set.seed(1)
subset2 <- sample((1:nrow(fdgs))[-subset1], 1000)
# Subset 1 + subset 2
fdgs.sub <- fdgs[c(subset1, subset2), ]
summary(fdgs.sub)


## -----------------------------------------------------------------------------
library("INLA")
hgt.inla <- inla(hgt ~ age + sex, data = fdgs.sub,
control.predictor = list(compute = TRUE))
summary(hgt.inla)


## -----------------------------------------------------------------------------
hgt.na <- which(is.na(fdgs.sub$hgt))[1:2]
rownames(fdgs.sub)[hgt.na]


## -----------------------------------------------------------------------------
hgt.inla$summary.fitted.values[hgt.na, c("mean", "sd")]


## -----------------------------------------------------------------------------
wgt.inla <- inla(wgt ~ age + sex, data = fdgs.sub,
control.predictor = list(compute = TRUE),
control.compute = list(config = TRUE))
summary(wgt.inla)


## -----------------------------------------------------------------------------
wgt.na <- which(is.na(fdgs.sub$wgt))
wgt.inla$summary.fitted.values[wgt.na[1:2], c("mean", "sd")]


## -----------------------------------------------------------------------------
n <- nrow(fdgs.sub)
y <- matrix(NA, nrow = 2 * n, ncol = 2)
y[1:n, 1] <- fdgs.sub$hgt
y[n + 1:n, 2] <- fdgs.sub$wgt


## -----------------------------------------------------------------------------
I <- matrix(NA, nrow = 2 * n, ncol = 2)
I[1:n, 1] <- 1
I[n + 1:n, 2] <- 1


## -----------------------------------------------------------------------------
SEX <- matrix(NA, nrow = 2 * n, ncol = 2)
SEX[1:n, 1] <- fdgs.sub$sex
SEX[n + 1:n, 2] <- fdgs.sub$sex


## -----------------------------------------------------------------------------
age.joint <- rep(fdgs.sub$age, 2)


## -----------------------------------------------------------------------------
idx.age = rep(1:2, each = n)


## -----------------------------------------------------------------------------
# Model formula
joint.f <- y ~ -1 + I + f(idx.age, age, model = "iid2d", n = 2) + SEX
# Model fit
fdgs.joint <- inla(joint.f, 
  data = list(y = y, I = I, SEX = SEX, age = age.joint, idx.age = idx.age),
  family = rep("gaussian", 2),
  control.predictor = list(compute = TRUE))
# Summary
summary(fdgs.joint)


## -----------------------------------------------------------------------------
fdgs.joint$summary.random$idx.age


## -----------------------------------------------------------------------------
fdgs.joint$summary.fitted.values[hgt.na, c("mean", "sd")]


## -----------------------------------------------------------------------------
fdgs.joint$summary.fitted.values[n + wgt.na[1:2], c("mean", "sd")]


## -----------------------------------------------------------------------------
hgt.noimp <- inla(hgt ~ 1 +  age + sex + wgt, data = fdgs.sub)
summary(hgt.noimp)


## -----------------------------------------------------------------------------
fdgs.plg <- fdgs.sub
fdgs.plg$wgt[wgt.na] <- wgt.inla$summary.fitted.values[wgt.na, "mean"]


## -----------------------------------------------------------------------------
summary(fdgs.plg$wgt)


## -----------------------------------------------------------------------------
hgt.plg <- inla(hgt ~ 1 +  age + sex + wgt, data = fdgs.plg,
control.predictor = list(compute = TRUE))
summary(hgt.plg)


## -----------------------------------------------------------------------------
hgt.plg$summary.fitted.values[hgt.na[1:2], ]


## ----echo = FALSE, eval = TRUE------------------------------------------------
load("data/fdgs.RData")


## ----eval = FALSE-------------------------------------------------------------
## n.imp <- 50
## wgt.pred <- inla.posterior.sample(n.imp, wgt.inla)


## -----------------------------------------------------------------------------
wgt.pred[[1]]$latent[wgt.na,]


## ----eval = FALSE-------------------------------------------------------------
## imp.models <- lapply(1:n.imp, function(i) {
##   fdgs.plg$wgt[wgt.na] <- wgt.pred[[i]]$latent[wgt.na, ]
##   inla(hgt ~ 1 +  age + sex + wgt, data = fdgs.plg,
##     control.predictor = list(compute = TRUE))
## })


## ----echo  = FALSE, eval = FALSE----------------------------------------------
## # Save results to speed-up computations
## save(file = "data/fdgs.RData", list = c("imp.models", "wgt.pred", "n.imp"))


## -----------------------------------------------------------------------------
model.imp <- inla.merge(imp.models, rep(1 / n.imp, n.imp))


## -----------------------------------------------------------------------------
marg.fixed <- model.imp$marginals.fixed
marg.hyperpar <- model.imp$marginals.hyperpar


## -----------------------------------------------------------------------------
summary(model.imp)


## -----------------------------------------------------------------------------
model.imp$summary.linear.predictor[hgt.na[1:2], ]


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## ws <- rep(1 / n.imp, n.imp)
## marg.fixed <- INLABMA:::fitmargBMA2(imp.models, ws, "marginals.fixed")
## marg.hyperpar <- INLABMA:::fitmargBMA2(imp.models, ws, "marginals.hyperpar")
## #marg.fitted <- INLABMA:::fitmargBMA2(imp.models, ws, "marginals.fitted.values")


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## sapply(hgt.na[1:2], function (i) {
##   margs <- lapply(imp.models, function(X){
##     X$marginals.fitted.values[[i]]
##   })
## 
##   marg.bma <- INLABMA:::fitmargBMA(margs, rep(1 / n.imp, n.imp))
##   inla.zmarginal(marg.bma, TRUE)
## })


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## margs1 <- lapply(imp.models, function(X){
##     X$marginals.fitted.values[[1]]
##   })
## marg.bma1 <- INLABMA:::fitmargBMA(margs1, rep(1 / n.imp, n.imp))


## ----label = "wgt-mis", fig = TRUE, results = "hide", echo = FALSE, fig.cap = '(ref:wgtmis)', fig.width = 6, fig.height = 3.45----
# ggplot version
library("ggplot2")
p <- ggplot(as.data.frame(model.imp$marginals.linear.predictor[[hgt.na[1]]]),
    aes(x = x, y = y)) +
  geom_line() +
  xlab("height") +
  ylab(expression(paste(pi, "(", hgt[i], " | ", bold(y), ")"))) +
  xlim(105, 130)

for(i in 1:length(imp.models)) {
  tab <- as.data.frame(imp.models[[i]]$marginals.linear.predictor[[hgt.na[1]]])

  p <- p + geom_line(data = tab, col = "grey")
}

p <- p + geom_line(data = as.data.frame(model.imp$marginals.linear.predictor[[hgt.na[1]]]), col = "black")

p


## -----------------------------------------------------------------------------
library("mice")

data(nhanes2)
summary(nhanes2)


## -----------------------------------------------------------------------------
m1 <- inla(chl ~ 1 + bmi + age, data = nhanes2)
summary(m1)


## -----------------------------------------------------------------------------
#Generic variables for model fitting
d.mis <- nhanes2
idx.mis <- which(is.na(d.mis$bmi))
n.mis <- length(idx.mis)


## -----------------------------------------------------------------------------
#Fit linear model with R-INLA with a fixed beta
#d.mis: Dataset
#x.mis: Imputed values
fit.inla <- function(data, x.mis) {

   data$bmi[idx.mis] <- x.mis

   res <- inla(chl ~ 1 + bmi + age, data = data)

   return(list(mlik = res$mlik[1,1], model = res))
}


## -----------------------------------------------------------------------------
#Proposal x -> y
#density
dq.beta <- function(x, y, sigma = sqrt(10), log =TRUE) {
	res <- dnorm(y, mean = x, sd = sigma, log = log)

	if(log) {
		return(sum(res))
	} else {
		return(prod(res))
	}
}
#random
rq.beta <- function(x, sigma = sqrt(10) ) {
	rnorm(length(x), mean = x, sd = sigma)
}


## -----------------------------------------------------------------------------
#Prior for beta
prior.beta <- function(x, mu = mean(d.mis$bmi, na.rm = TRUE), 
   sigma = 2*sd(d.mis$bmi, na.rm = TRUE), log = TRUE) {
   res <- dnorm(x, mean = mu, sd= sigma, log = log)

	if(log) {
		return(sum(res))
	} else {
		return(prod(res))
	}
}


## ----eval = FALSE-------------------------------------------------------------
## library("INLABMA")
## # Set initial values to mean of bmi
## d.init <- rep(mean(d.mis$bmi, na.rm = TRUE), n.mis)
## #Run MCMC simulations
## inlamh.res <- INLAMH(d.mis, fit.inla, d.init,
##   rq.beta, dq.beta, prior.beta,
##   n.sim = 100, n.burnin = 50, n.thin = 10)


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## save(file = "results/nhanes2-MH.RData", list = c("inlamh.res"))


## ----echo = FALSE-------------------------------------------------------------
load("results/nhanes2-MH.RData")


## -----------------------------------------------------------------------------
#Show results
x.sim <- do.call(rbind, inlamh.res$b.sim)
summary(x.sim)


## ----label = "impbmi", fig = TRUE, echo = FALSE, fig.cap = '(ref:nhanes2)'----
#par(mfrow = c(3, 3))
#for(i in 1:9) {
#  plot(density(x.sim[, i]), xlab = "", ylab = "", main = "")
#}

library("ggplot2")
tab <- data.frame(impbmi = do.call(c, inlamh.res$b.sim),
  idx = rep(paste("Subject ", idx.mis, sep = ""), 100))
ggplot(tab, aes(impbmi)) + facet_wrap(~ idx) + geom_density() +
  xlab("Body mass index")


## -----------------------------------------------------------------------------
nhanes2.models <- lapply(inlamh.res$model.sim, function(X) { X$model })
nhanes2.imp <- inla.merge(nhanes2.models, rep(1, length(nhanes2.models)))
summary(nhanes2.imp)

