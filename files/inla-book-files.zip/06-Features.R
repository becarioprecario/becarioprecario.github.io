## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library(knitr)
opts_chunk$set(
  fig.path = 'figs/06-Features-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library(INLA)


## ------------------------------------------------------------------------
library(MASS)
library(Matrix)

data(cement)
A <- Diagonal(n = nrow(cement), x = 5)
summary(A)


## ------------------------------------------------------------------------
m1.A <- inla(y ~ x1 + x2 + x3 + x4, data = cement,
  control.predictor = list(A = A))
summary(m1.A)


## ----results = "hide"----------------------------------------------------
inla.make.lincomb(x1 = 1, x2 = -1)


## ----results = "hide"----------------------------------------------------
inla.make.lincomb(u = c(1, -1, NA, NA))


## ----results = "hide"----------------------------------------------------
inla.make.lincomb(
  x1 = c( 1,  1,  1),
  x2 = c(-1,  0,  0),
  x3 = c( 0, -1,  0),
  x4 = c( 0,  0, -1)
)


## ------------------------------------------------------------------------
library(faraway)
data(abrasion)

# Prior prec. of random effects
prec.prior <- list(prec = list(param = c(0.5, 95)))
# Model formula
f.wear <- wear ~ -1 + material + 
    f(position, model = "iid", hyper = prec.prior) +
    f(run, model = "iid", hyper = prec.prior)

# Model fitting
m0 <- inla(f.wear, data = abrasion,
  control.fixed = list(prec = 0.001^2)
)
# Improve estimates of hyperparameters
m0 <- inla.hyperpar(m0)
summary(m0)


## ------------------------------------------------------------------------
lc <- inla.make.lincomb(materialA = 1, materialB = -1)


## ------------------------------------------------------------------------
m0.lc <- inla.hyperpar(inla(f.wear, data = abrasion, lincomb = lc,
  control.fixed = list(prec = 0.001^2)))
summary(m0.lc)


## ------------------------------------------------------------------------
m0.lc$summary.lincomb.derived


## ------------------------------------------------------------------------
lcs <- inla.make.lincombs(
  materialA = c( 1,  1,  1),
  materialB = c(-1,  0,  0),
  materialC = c( 0, -1,  0),
  materialD = c( 0,  0, -1)
)


## ------------------------------------------------------------------------
m0.lcs <- inla.hyperpar(inla(f.wear, data = abrasion, lincomb = lcs,
  control.fixed = list(prec = 0.001^2)))
summary(m0.lcs)


## ------------------------------------------------------------------------
lc.pos <- inla.make.lincomb(position = c(1, -1, NA, NA))

m0.pos <- inla.hyperpar(inla(f.wear, data = abrasion, lincomb = lc.pos,
  control.fixed = list(prec = 0.001^2)))
summary(m0.pos)


## ------------------------------------------------------------------------
lc.eff <- inla.make.lincomb(materialA = 1, position = c(1, NA, NA, NA),
  run = c(NA, 1, NA, NA))
m0.eff <- inla.hyperpar(inla(f.wear, data = abrasion, lincomb = lc.eff,
  control.fixed = list(prec = 0.001^2)))
summary(m0.eff)


## ------------------------------------------------------------------------
set.seed(314)
# Gaussian data
d1 <- rnorm(30)

# Poisson data
d2 <- rpois(20, 10)


## ------------------------------------------------------------------------
# Data
d <- matrix(NA, ncol = 2, nrow = 30 + 20)
d[1:30, 1] <- d1
d[30 + 1:20, 2] <- d2


## ------------------------------------------------------------------------
# Define a different intercept for each likelihood
Intercept1 <- c(rep(1, 30), rep(NA, 20))
Intercept2 <- c(rep(NA, 30), rep(1, 20))


## ------------------------------------------------------------------------
x <- rnorm(30 + 20)


## ------------------------------------------------------------------------
mult.lik <- inla(Y ~ -1 + I1 + I2 + x,
  data = list(Y = d, I1 = Intercept1, I2 = Intercept2, x = x),
  family = c("gaussian", "poisson"))

summary(mult.lik)


## ------------------------------------------------------------------------
set.seed(271)
#Covariate
xx <- runif(200, 1, 2)
#Gaussian data
y.gaus <- rnorm(150, mean = 2 * xx[1:150])
#Poisson data
y.pois <- rpois(50, lambda = exp(2 * xx[151:200]))


## ------------------------------------------------------------------------
y <- matrix(NA, ncol = 2, nrow = 200)
y[1:150, 1] <- y.gaus
y[151:200, 2] <- y.pois


## ------------------------------------------------------------------------
idx.gaus <- c(rep(1, 150), rep(NA, 50))
idx.pois <- c(rep(NA, 150), rep(1, 50))


## ------------------------------------------------------------------------
m.copy <- inla(y ~ -1 + f(idx.gaus, xx, model = "iid") +
  f(idx.pois, xx, copy = "idx.gaus",
    hyper = list(beta = list(fixed = FALSE))),
  data = list(y = y, xx = xx),
  family = c("gaussian", "poisson")
)
summary(m.copy)


## ------------------------------------------------------------------------
m.copy$summary.random


## ------------------------------------------------------------------------
library(dlm)
data(NelPlo, package = "dlm")
summary(NelPlo)


## ----label = "NelPlo", fig = TRUE, echo = FALSE, fig.cap = '(ref:NelPlo)'----
plot(NelPlo)


## ------------------------------------------------------------------------
nelplo <- as.vector(NelPlo)


## ------------------------------------------------------------------------
#Number of years
n <- nrow(NelPlo)

#Index for the ar1 latent effect
idx.ts <- rep(1:n, 2)
# Index for the replicate effect
idx.rep <- rep(1:2, each = n)


## ------------------------------------------------------------------------
# Intercepts
i1 <- c(rep(1, n), rep(NA, n))
i2 <- c(rep(NA, n), rep(1, n))


## ------------------------------------------------------------------------
m.rep <- inla(nelplo ~ -1 + i1 + i2 + 
  f(idx.ts, model = "ar1", replicate = idx.rep, 
    hyper = list(prec = list(param = c(0.001, 0.001)))),
  data = list(nelplo = nelplo, i1 = i1, i2 = i2, idx.ts = idx.ts,
    idx.rep = idx.rep),
  control.predictor = list(compute = TRUE)
)
summary(m.rep)


## ----label = "fitrep", fig = TRUE, echo = FALSE, fig.cap = '(ref:fitrep)'----
library(ggplot2)
library(gridExtra)
tab <- data.frame(year = 1946:1988,
  ip.fit = m.rep$summary.fitted.values[1:n, "mean"],
  stock.fit = m.rep$summary.fitted.values[n + 1:n, "mean"]
)

p1 <- ggplot(tab, aes(x = year, y = ip.fit)) + geom_line() +
  ggtitle(" Fitted values of industrial production") +
  ylab("Industrial production") +
  geom_point(data = as.data.frame(NelPlo[, 1]),
    aes(x = 1946:1988, y = x))

p2 <- ggplot(tab, aes(x = year, y = stock.fit)) + geom_line() +
  ggtitle(" Fitted values of stock prices") +
  ylab("Stock price") + 
  geom_point(data = as.data.frame(NelPlo[, 2]),
    aes(x = 1946:1988, y = x))

grid.arrange(p1, p2, nrow = 2)


## ------------------------------------------------------------------------
A <- matrix(1, ncol = n, nrow = 1)
e <- matrix(0, ncol = 1)


## ------------------------------------------------------------------------
m.unconstr <- inla(ip ~ -1 + f(idx, model = "ar1"),
  data = list(ip = NelPlo[, 1], idx = 1:n),
  control.family = list(hyper = list(prec = list(initial = 10,
    fixed = TRUE))),
  control.predictor = list(compute = TRUE)
)

m.constr <- inla(ip ~ -1 + f(idx, model = "ar1",
    extraconstr = list(A = A, e = e)),
  data = list(ip = NelPlo[, 1], idx = 1:n),
  control.family = list(hyper = list(prec = list(initial = 10,
    fixed = TRUE))),
  control.predictor = list(compute = TRUE)
)


## ----label = "extraconstr", efig = TRUE, echo = FALSE, fig.cap = "Comparison between two random effects estimates using a sum-to-zero constraint (solid line)  and no constraint (dashed lines)."----
tab <- data.frame(year = 1946:1988, 
  ip.unconstr = m.unconstr$summary.random$idx[, "mean"],
  ip.constr = m.constr$summary.random$idx[, "mean"]
)

ggplot(tab, aes(x = year, y = ip.unconstr)) + geom_line(linetype = "solid") +
  ylab("Industrial production") + 
  geom_line(aes(x = year, y = ip.constr), linetype = "dashed") +
  geom_point(data = as.data.frame(NelPlo[, 1]),
    aes(x = 1946:1988, y = x))

