## ----sett10, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/09-Survival-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
library("survival")
data(veteran) 

veteran$trt <- as.factor(veteran$trt)
levels(veteran$trt) <- c("standard", "test")
veteran$prior <- as.factor(veteran$prior)
levels(veteran$prior) <- c("No", "Yes")


## ----message = FALSE, eval = TRUE---------------------------------------------
veteran$time.m <- round(veteran$time / 30, 3)


## -----------------------------------------------------------------------------
surv.vet <- Surv(veteran$time.m, veteran$status)
surv.vet[1:20]


## -----------------------------------------------------------------------------
km.vet <- survfit(surv.vet ~ 1)


## -----------------------------------------------------------------------------
km.vet.cell <- survfit(surv.vet ~ -1 + celltype, data = veteran)


## ----fig = TRUE, label = "KMvetcell", fig.cap = "Survival estimates of patients according to histological type of tumor (i.e., cell type).", echo = FALSE, fig.height = 4, fig.width = 8----
library("ggfortify")
autoplot(km.vet.cell, censor.colour = "red")


## ----message = FALSE----------------------------------------------------------
library("INLA")
sinla.vet <- inla.surv(veteran$time.m, veteran$status)


## -----------------------------------------------------------------------------
exp.vet <- inla(sinla.vet ~ 1, data = veteran, family = "exponential.surv")
summary(exp.vet)


## -----------------------------------------------------------------------------
library("parallel")
# Set number of cores to use
options(mc.cores = 4)
# Grid of times
times <- seq(0.01, 35, by = 1)
# Marginal of alpha
alpha.marg <- exp.vet$marginals.fixed[["(Intercept)"]]
# Compute post. marg. of survival function
S.inla <- mclapply(times, function(t){
  S.marg <- inla.tmarginal(function(x) {exp(- exp(x) * t)}, alpha.marg)
  S.stats <- inla.zmarginal(S.marg, silent = TRUE)
  return(unlist(S.stats[c("quant0.025", "mean", "quant0.975")]))
})

S.inla <- as.data.frame(do.call(rbind, S.inla))


## ----fig = TRUE, label = "Svet", fig.cap = "Kaplan-Meier estimate (left) and survival function using an exponential model (right) for the `veteran` dataset.", echo = FALSE, fig.height = 4, fig.width = 8----
#plot(times, S.inla$mean, type = "l", ylim = c(0, 1), 
#  xlab = expression(t), ylab = expression(S(t)))
#lines(times, S.inla$quant0.025, lty = 2)
#lines(times, S.inla$quant0.975, lty = 2)
#abline(h = 0.5, lty =2, col = "red")

library("gridExtra")

# Kaplan-Meier
plot1 <- autoplot(km.vet, censor.colour = "red")

# MOdel fit
tab <- data.frame(surv = S.inla$mean, time = times, ll95 = S.inla$quant0.025,
  ul95 = S.inla$quant0.975)

plot2 <- ggplot(tab) + geom_line(aes(x = time, y = surv)) +
  geom_ribbon(aes(x = time, ymin = ll95, ymax = ul95),
    alpha = 0.65, data = tab)

grid.arrange(plot1, plot2, ncol = 2)


## -----------------------------------------------------------------------------
coxinla.vet <- inla(sinla.vet ~ 1  + celltype + trt, data = veteran,
  family = "coxph",
  control.hazard = list(hyper = list(prec = list(param = c(0.001, 0.001)))))
summary(coxinla.vet)


## ----results = "hide"---------------------------------------------------------
#Transform baseline hazard
h0 <- lapply(coxinla.vet$marginals.random[["baseline.hazard"]],
  function(X) {inla.tmarginal(exp, X)}
)
#Compute summary statistics for plotting
h0.stats <- lapply(h0, inla.zmarginal)



## -----------------------------------------------------------------------------
h0.df <- data.frame(t = coxinla.vet$summary.random[["baseline.hazard"]]$ID)
h0.df <- cbind(h0.df, do.call(rbind, lapply(h0.stats, unlist)))


## ----echo = FALSE, results = "asis", eval = FALSE-----------------------------
## #Table \@ref(tab:hazardfunction) shows summary statistics of the hazard
## #function fit to the `veteran` dataset.
## 
## # COlumns to show
## tab <- h0.df[, c(1:4, 8)]
## #Show table
## knitr::kable(tab,  digits = 2, format = "markdown",
##   escape = FALSE, row.names = FALSE,
##   caption = "Table: (\\#tab:hazardfunction) Point estimates of the hazard function fit to the `veteran` dataset.")
## cat("\nTable: (\\#tab:hazardfunction) Point estimates of the hazard function fit to the `veteran` dataset.\n")


## ----fig = TRUE, label = "vet-haz", echo = FALSE, fig.cap = "Posterior mean (solid line) and 95% credible interval (dashed lines) of baseline hazard function estimate using a Cox model on the `veteran` dataset.", fig.height = 3.45, fig.width = 6----
#ggplot version

tab <- data.frame(t = h0.df$t, pmean = h0.df$mean, q0025 = h0.df$"quant0.025",
  q0975 = h0.df$"quant0.975")

ggplot(tab, aes(x = t, y = pmean)) + 
  geom_hline(yintercept = 1, linetype = "dotted", col = "red") +
  geom_line() +
  xlab("Time") + ylab(expression(h [0] ~ (t))) + 
  geom_line(aes(x = t, y = q0025), linetype = 2) +
  geom_line(aes(x = t, y = q0975), linetype = 2) 


## ----message = FALSE, eval = TRUE---------------------------------------------
logninla.vet <- inla(sinla.vet ~ -1 + celltype + trt, data = veteran,
  family = "lognormal.surv")


## -----------------------------------------------------------------------------
summary(logninla.vet)


## ----eval = TRUE--------------------------------------------------------------
lapply(logninla.vet$marginals.fixed, function(X){1 - inla.pmarginal(0, X)})


## -----------------------------------------------------------------------------
weibinla.vet <- inla(sinla.vet ~ -1 + celltype + trt,
  data = veteran, family = "weibull.surv",
  control.family = list(variant=0))


## -----------------------------------------------------------------------------
summary(weibinla.vet)


## -----------------------------------------------------------------------------
lapply(weibinla.vet$marginals.fixed, function(X){inla.pmarginal(0, X)})


## -----------------------------------------------------------------------------
data(retinopathy)

#Recode some covariates as factors
retinopathy$trt <- as.factor(c("control", "treated")[retinopathy$trt + 1])

#Summary
summary(retinopathy)


## -----------------------------------------------------------------------------
retinopathy$futime <- retinopathy$futime / 12


## -----------------------------------------------------------------------------
surv.ret <- Surv(retinopathy$futime, retinopathy$status)

km.ret <- survfit(surv.ret ~ 1)


## ----fig = TRUE, label = "KM-retino", echo = FALSE, fig.cap = "Survival function of the `retinopathy` dataset.", fig.width = 8, fig.height = 4----
autoplot(km.ret, main = "Survival function (retinopathy data)")


## -----------------------------------------------------------------------------
# Model formula
form <- inla.surv(futime, status) ~ 1 + trt + risk + f(id, model = "iid",
  hyper = list(prec = list(param = c(0.001, 0.001))))

# Model fitting
fr.ret <- inla(form, data = retinopathy,
  family  = "weibullsurv")


## -----------------------------------------------------------------------------
summary(fr.ret)


## ----fig = TRUE, echo = FALSE, label = "frailty", fig.cap = "95% credible intervals of the frailties in the retinopathy dataset analysis.", fig.height = 4, fig.width = 8----
# ggplot version
n.pat <- nrow(fr.ret$summary.random$id)

tab <- data.frame(patient = 1:n.pat, 
  low.lim = fr.ret$summary.random$id[, "0.025quant"],
  upp.lim = fr.ret$summary.random$id[, "0.975quant"])

ggplot(tab, aes(x = patient, y = low.lim)) +
  geom_linerange(aes(ymin = low.lim, ymax = upp.lim), col = "gray40") +
  xlab("Patient") +
  ylab("Effect") +
  coord_flip() + 
  geom_hline(yintercept = 0, linetype = "dashed", col = "gray20")


## ----message = FALSE, warning = FALSE-----------------------------------------
library("JMbayes")
data(prothros)
summary(prothros)


## -----------------------------------------------------------------------------
#prothros$Time <- prothros$Time  / max(prothros$Time) # Re-scaling
pro.surv <- inla.surv(prothros$Time, prothros$death)

form.pro.surv <- pro.surv ~ 1 + treat

pro.surv.inla <- inla(form.pro.surv, data = prothros,
  family = "weibull.surv")

summary(pro.surv.inla)


## ----message = FALSE, warning = FALSE-----------------------------------------
data(prothro)
summary(prothro)


## -----------------------------------------------------------------------------
form.pro.long <- pro ~ 1 + time + f(id, model = "iid") + treat
pro.long.inla <- inla(form.pro.long, data = prothro, family = "lognormal")
summary(pro.long.inla)


## -----------------------------------------------------------------------------
#Number of observations in each dataset
n.l <- nrow(prothro)
n.s <- nrow(prothros)

#Vector of NA's
NAs.l <- rep(NA, n.l)
NAs.s <- rep(NA, n.s)
#Vector of zeros
zeros.l <- rep(0, n.l)
zeros.s <- rep(0, n.s)


## -----------------------------------------------------------------------------
#Long. and survival responses
Y.long <- c(prothro$pro, NAs.s)
Y.surv <- inla.surv(time = c(NAs.l, prothros$Time),
  event = c(NAs.l, prothros$death))

Y.joint <- list(Y.long, Y.surv)


## -----------------------------------------------------------------------------
#Covariates
covariates <- data.frame(
  #Intercepts (as factor with 2 levels)
  inter = as.factor(c(rep("b.l", n.l), rep("b.s", n.s))),
  #Time
  time.l = c(prothro$time, NAs.s),
  time.s = c(NAs.l, prothros$Time),
  #Treatment (longitudinal)
  treat.l = c(as.integer(prothro$treat =="prednisone"), NAs.s),
  #Treat.s
  treat.s = c(NAs.l, as.integer(prothros$treat =="prednisone"))
)

#Indices for random effects
r.effects <- list(
  #Patiend id (long.)
  id.l = c(prothro$id, NAs.s),
  #Patient id (surv.)
  id.s = c(NAs.l, prothros$id)
)


## -----------------------------------------------------------------------------
joint.data  <- c(covariates, r.effects)
joint.data$Y <- Y.joint



## -----------------------------------------------------------------------------
pro.joint.inla <- inla(Y ~ -1 + inter +
    # Longitudinal part
    f(id.l) + 
    time.l + treat.l +
    #Survival part
    treat.s,
  data = joint.data, family = c("lognormal", "weibull.surv")
)

summary(pro.joint.inla)


## -----------------------------------------------------------------------------
#Unique index for patient from 1 to n.patients
unique.id <- unique(prothro$id)
n.id <- length(unique.id)
idx <- 1:n.id

#Unique indices for long. and survival data
idx.l <- match(prothro$id, unique.id )
idx.s <- match(prothros$id, unique.id )


## -----------------------------------------------------------------------------
#Indices for random intercept
joint.data$idx.sh.l <- c(idx.l, NAs.s)
joint.data$idx.sh.l2 <- c(idx.l, NAs.s)

#Indices for coefficient of time
joint.data$idx.sh.s <- c(NAs.l, idx.s)
joint.data$idx.sh.s2 <- c(NAs.l, idx.s)


## -----------------------------------------------------------------------------
pro.joint.inla2 <- inla(Y ~ -1 +
    #Intercepts
    inter +
    #Longitudinal model
    time.l + treat.l +
    f(idx.sh.l, model = "iid") +
    f(idx.sh.l2, time.l, model = "iid") +
    #Survival model
    treat.s +
    f(idx.sh.s, copy = "idx.sh.l", fixed = FALSE) +
    f(idx.sh.s2, time.s, copy = "idx.sh.l", fixed = FALSE),
  data = joint.data,
  family = c("lognormal", "weibull.surv")
)

summary(pro.joint.inla2)



## ----fig = TRUE, echo = FALSE, label = "joint-prothro", fig.cap = '(ref:jointprothro)'----
# ggplot version
tab <- data.frame(x = pro.joint.inla2$summary.random$idx.sh.l$mean,
  y = pro.joint.inla2$summary.random$idx.sh.s$mean)

ggplot(tab, aes(x = x, y = y)) + geom_point() + 
  xlab("Patient specific intercept (long.)") +
  ylab("Patient specific intercept (surv.)") +
  geom_abline(intercept = 0, slope = pro.joint.inla2$summary.hyperpar[5, "mean"], col = "red")


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## #Finally, Table \@ref(tab:joint) provides summary statistics of the model parameters.
## #Use same notation as in the jags code
## 
## joint.res <- data.frame(
## Parameter = c("$beta0.l", "beta1.l", "beta2.l", "beta.s", "gamma0", "gamma1",
##   "lambda", "alpha", "sigma", "sigma0", "sigma1")
## )
## 
## joint.res <- cbind(joint.res, mean = NA, sd = NA, Q2.5 = NA, median = NA,
##   Q97.5 = NA)
## 
## #Intercept of long. part
## joint.res[1, -1] <- pro.joint.inla2$summary.fixed["interb.l", c(1, 2, 3, 4, 5)]
## 
## #Time coef., long. part
## joint.res[2, -1] <- pro.joint.inla2$summary.fixed["time.l", c(1, 2, 3, 4, 5)]
## 
## #Treatment coef., long part
## joint.res[3, -1] <- pro.joint.inla2$summary.fixed["treat.l", c(1, 2, 3, 4, 5)]
## 
## #Treatment coef., surv. part
## joint.res[4, -1] <- pro.joint.inla2$summary.fixed["treat.s", c(1, 2, 3, 4, 5)]
## 
## #Gamma0
## joint.res[5, -1] <- pro.joint.inla2$summary.hyper["Beta for idx.sh.s", c(1, 2, 3, 4, 5)]
## 
## #Gamma1
## joint.res[6, -1] <- pro.joint.inla2$summary.hyper["Beta for idx.sh.s2", c(1, 2, 3, 4, 5)]
## 
## #Lambda
## marg.lambda <- inla.tmarginal(exp, pro.joint.inla2$marginals.fixed$interb.s)
## joint.res[7, -1] <- unlist(inla.zmarginal(marg.lambda, TRUE))[c(1, 2, 3, 5, 7)]
## 
## #Alpha
## joint.res[8, -1] <- pro.joint.inla2$summary.hyperpar["alpha parameter for weibullsurv[2]", 1:5]
## 
## 
## #Sigma
## marg.sigma <- inla.tmarginal(function(x) {1/sqrt(x)},
##   pro.joint.inla2$marginals.hyperpar[["Precision for the lognormal observations"]])
## 
## joint.res[9, -1] <- unlist(inla.zmarginal(marg.sigma, TRUE))[c(1, 2, 3, 5, 7)]
## 
## #Sigma0
## marg.sigma0 <- inla.tmarginal(function(x) {1/sqrt(x)},
##   pro.joint.inla2$marginals.hyperpar[["Precision for idx.sh.l (component 1)"]])
## 
## joint.res[10, -1] <- unlist(inla.zmarginal(marg.sigma0, TRUE))[c(1, 2, 3, 5, 7)]
## 
## #Sigma1
## marg.sigma1 <- inla.tmarginal(function(x) {1/sqrt(x)},
##   pro.joint.inla2$marginals.hyperpar[["Precision for idx.sh.l (component 2)"]])
## 
## joint.res[11, -1] <- unlist(inla.zmarginal(marg.sigma1, TRUE))[c(1, 2, 3, 5, 7)]
## 
## knitr::kable(joint.res, digits = 2,
##    caption = "(\\#tab:joint) Summary of estimates of the parameters for the joint model.")

