## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/13-Mixture-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
library("MASS")
data(geyser)
summary(geyser)


## ----label = "geyser2", fig = TRUE, echo = FALSE, fig.cap = "", fig.height = 4, fig.width = 8, fig.cap = '(ref:geyser)', eval = FALSE----
## par(mfrow = c(1, 2))
## 
## #Bivariate plot
## plot(geyser, main = "Old Faithful dataset")
## 
## #Histogram and density plot
## hist(geyser$duration, main = "Duration of eruption", freq = FALSE,
##   xlab = "duration", breaks = 20)
## lines(density(geyser$duration))


## ----label = "geyser", fig = TRUE, echo = FALSE, fig.height = 4, fig.width = 8, fig.cap = '(ref:geyser)'----
# ggplot version
library("ggplot2")
library("gridExtra")

# Bivariate plot
p1 <- ggplot(geyser, aes (x = waiting, y = duration)) + geom_point() +
  ggtitle("Old Faithful dataset")

#Histogram and density plot
p2 <- ggplot(geyser, aes(x = duration)) + 
  geom_histogram(aes(y=..density..), bins = 20) +
  geom_density(aes(y=..density..)) +
  ggtitle("Duration of eruption")

grid.arrange(p1, p2, nrow = 1)


## -----------------------------------------------------------------------------
#Index of group 1
idx1 <- geyser$duration <=3


## -----------------------------------------------------------------------------
table(idx1)


## -----------------------------------------------------------------------------
# Empty response
yy <- matrix(NA, ncol = 2, nrow = nrow(geyser))

#Add data
yy[idx1, 1] <- geyser$duration[idx1]
yy[!idx1, 2] <- geyser$duration[!idx1]


## -----------------------------------------------------------------------------
#Create two different intercepts
II <- yy
II[II > 0] <- 1


## -----------------------------------------------------------------------------
#Fit model with INLA
geyser.inla <- inla(duration ~ -1 + Intercept,
  data = list(duration = yy, Intercept = II), 
  family = c("gaussian", "gaussian"))
summary(geyser.inla)


## -----------------------------------------------------------------------------
# Number of groups
n.grp <- 2

# Initial classification
grp <- rep(1, length(geyser$duration))
grp[!idx1] <- 2


## -----------------------------------------------------------------------------
#y: Vector of values with the response.
#grp: Vector of integers with the allocation variable.
fit.inla.internal <- function(y, grp) {

  #Data in two-column format
  yy <- matrix(NA, ncol = n.grp, nrow = length(y))
  for(i in 1:n.grp) {
    idx <- which(grp == i)
    yy[idx, i] <- y[idx]
  }

  #X stores the intercept in the model
  x <- yy
  x[!is.na(x)] <- 1
  
  d <- list(y = yy, x = x)

  #Model fit (conditional on z)
  m1 <- inla(y ~ -1 + x, data = d,
    family = rep("gaussian", n.grp),
    #control.fixed = list(mean = list(x1 = 2, x2 = 4.5), prec = 1)
    control.fixed = list(mean = prior.means, prec = 1)
  )

  res<- list(model = m1, mlik = m1$mlik[1, 1])
  return(res)
}


## -----------------------------------------------------------------------------
y <- geyser$duration

prior.means <- list(x1 = 2, x2 = 4.5)
scale.sigma <- 1.25
grp.init <- list(z = grp, m = fit.inla.internal(y, grp))


## -----------------------------------------------------------------------------
#Probabilities of belonging to each group
#z: Vector of integers with values from 1 to the number of groups
get.probs <- function(z) {
  probs <- rep(0, n.grp)
  tab <- table(z)
  probs[as.integer(names(tab))] <- tab / sum(tab)
  return(probs)
}


## -----------------------------------------------------------------------------
#Using means of conditional marginals
#FIXME: We do not consider possble label switching here
#z.old: Current value of z.
#z.new: Proposed value of z.
#log: Compute density in the log-scale.
dq.z <- function(z.old, z.new, log = TRUE) {
  m.aux <- z.old$m$model 
  means <- m.aux$summary.fixed[, "mean"]
  precs <- m.aux$summary.hyperpar[, "mean"]

  ww <- get.probs(z.old$z)

  z.probs <- sapply(1:length(y), function (X) {
    aux <- ww * dnorm(y[X], means, scale.sigma * sqrt(1 / precs))
    (aux / sum(aux))[z.new$z[X]]
  })

  if(log) {
    return(sum(log(z.probs)))
  } else {
    return(prod(z.probs))
  }
}


## -----------------------------------------------------------------------------
#FIXME: We do not consider possible label switching here
#z: Current value of z.
rq.z <- function(z) {
  m.aux <- z$m$model 
  means <- m.aux$summary.fixed[, "mean"]
  precs <- m.aux$summary.hyperpar[, "mean"]

  ws <- get.probs(z$z)

  z.sim <- sapply(1:length(z$z), function (X) {
    aux <- ws * dnorm(y[X], means, scale.sigma * sqrt(1 / precs))
    sample(1:n.grp, 1, prob = aux / sum(aux))
  })

  #Fit model
  z.model <- fit.inla.internal(y, z.sim)

  #New value
  z.new <- list(z = z.sim, m = z.model)

  return(z.new)
}


## -----------------------------------------------------------------------------
#z: Vector of integer values from 1 to K.
prior.z <- function(z, log = TRUE) {

  res <- log(1 / n.grp) * length(z$z)
  if(log) {
    return(res)
  }
  else {
    return(exp(res))
  }
}


## -----------------------------------------------------------------------------
fit.inla <- function(y, grp) {
  return(grp$m)
}


## ----eval = FALSE-------------------------------------------------------------
## #Run simulations
## library("INLABMA")
## inlamh.res <- INLAMH(geiser$duration, fit.inla, grp.init, rq.z, dq.z,
##   prior.z, n.sim = 100, n.burnin = 20, n.thin = 5, verbose = TRUE)


## ----echo = FALSE-------------------------------------------------------------
load("data/geyser-MH.RData")


## -----------------------------------------------------------------------------
zz <- do.call(rbind, lapply(inlamh.res$b.sim, function(X){X$z}))


## -----------------------------------------------------------------------------
zz.probs <- apply(zz, 2, get.probs)



## -----------------------------------------------------------------------------
mliks <- do.call(rbind, lapply(inlamh.res$model.sim, function(X){X$mlik}))


## ----label = "geyser-probs", echo = FALSE, fig = TRUE, fig.cap = "Posterior probabilities of the observed data (left) and conditional marginal likelihood (right) of the model fit to the duration of geyser eruptions (in minutes).",  fig.width = 6, fig.height = 3.45----
# ggplot version

# Posterior probabilities
tab <- data.frame(duration = geyser$duration, pprob = zz.probs[1, ])

p1 <- ggplot(tab, aes(x = duration, y = pprob)) + geom_point() +
  xlab("Duration") +
  ylab(expression(paste(pi, "(", z[i]==1, " | ", bold(y), ")")))

# Conditional marg. lik.
tab <- data.frame(iter = 1:length(mliks), mliks = mliks)

p2 <- ggplot(tab, aes(x = iter, y = mliks)) + geom_line() +
  xlab("Iteration") +
  ylab(expression(paste(pi, "(", bold(y), " | ", bold(z), ")")))

grid.arrange(p1, p2, ncol = 2)


## -----------------------------------------------------------------------------
z.idx <- 60


## -----------------------------------------------------------------------------
#Marginal likelihood (log-scale)
mliks[z.idx]


## -----------------------------------------------------------------------------
#Prior (log-scale)
prior.z(inlamh.res$b.sim[[z.idx]])


## -----------------------------------------------------------------------------
#Posterior probabilities
z.post <- table(apply(zz, 1, function(x) {paste(x, collapse = "")})) / 100

# Get post. prob. of z^* in the log-scale
log.pprob <- unname( 
  log(z.post[names(z.post) ==
    paste(inlamh.res$b.sim[[z.idx]]$z, collapse = "")])
)
log.pprob


## -----------------------------------------------------------------------------
mlik.mix <- mliks[z.idx] + prior.z(inlamh.res$b.sim[[z.idx]]) - log.pprob
mlik.mix


## -----------------------------------------------------------------------------
inla(duration ~ 1, data = geyser)$mlik[1,1]


## ----eval = FALSE-------------------------------------------------------------
## #Number of groups
## n.grp <- 3
## 
## #Initial classification
## grp3 <- as.numeric(cut(geyser$duration, 3))
## grp.init3 <- list(z = grp3, m = fit.inla.internal(y, grp3))


## -----------------------------------------------------------------------------
#Priors for  the means
prior.means <- list(x1 = 2, x2 = 3.5, x3 = 5)
#Scale st. dev. of proposal distribution
scale.sigma <- 1


## ----eval = FALSE-------------------------------------------------------------
## inlamh.res3 <- INLAMH(geiser$duration, fit.inla, grp.init3, rq.z, dq.z,
##   prior.z, n.sim = 100, n.burnin = 20, n.thin = 5, verbose = TRUE)


## ----echo = FALSE-------------------------------------------------------------
load("data/geyser-MH3.RData")


## -----------------------------------------------------------------------------
##Conditional (on z) marg. lik.
mliks3 <- do.call(rbind, lapply(inlamh.res3$model.sim, function(X){X$mlik}))
#z^* with maximum cond. marg. lik.
z.idx3 <- which.max(mliks3)


## -----------------------------------------------------------------------------
#Get all values of z in the sample
zz3 <- do.call(rbind, lapply(inlamh.res3$b.sim, function(X){X$z}))
#Table of posterior probabilities
z.post3 <- table(apply(zz3, 1, function(x) {paste(x, collapse = "")})) / 100

#Log-posterior probability of z^*
log.pprob3 <- unname(
  log(z.post3[names(z.post3) == paste(inlamh.res3$b.sim[[z.idx3]]$z,
     collapse = "")])
)


## -----------------------------------------------------------------------------
#Marginal likelihood 
mlik.mix3 <- mliks3[z.idx3] + prior.z(inlamh.res3$b.sim[[z.idx3]]) -
  log.pprob3
mlik.mix3


## -----------------------------------------------------------------------------
#Merge models
models <- lapply(inlamh.res$model.sim, function(X) {X$model})
mix.model <- inla.merge(models)

#Post. means
mix.means <- mix.model$summary.fixed[, "mean"]
mix.precs <- mix.model$summary.hyperpar[, "mean"]

#Post. means of weights
n.grp <- 2
mix.w <- apply(apply(zz, 1, get.probs), 1, mean)


## -----------------------------------------------------------------------------
#Merge models
models3 <- lapply(inlamh.res3$model.sim, function(X) {X$model})
mix.model3 <- inla.merge(models3)

#Post. means
mix.means3 <- mix.model3$summary.fixed[, "mean"]
mix.precs3 <- mix.model3$summary.hyperpar[, "mean"]

#Post. means of weights
n.grp <- 3
mix.w3 <- apply(apply(zz3, 1, get.probs), 1, mean)


## ----label = "mixturemode", fig = TRUE, echo = FALSE, fig.cap = '(ref:mixturemode)',  fig.width = 6, fig.height = 3.75----
# ggplot version

xx<- seq(0, 6, by = 0.025)

mix.marg <- sapply(xx, function(x) {
  mix.w[1] * dnorm(x, mix.means[1], 1 / sqrt(mix.precs[1])) + 
  mix.w[2] * dnorm(x, mix.means[2], 1 / sqrt(mix.precs[2])) 
})

mix.marg3 <- sapply(xx, function(x) {
  mix.w3[1] * dnorm(x, mix.means3[1], 1 / sqrt(mix.precs3[1])) + 
  mix.w3[2] * dnorm(x, mix.means3[2], 1 / sqrt(mix.precs3[2])) + 
  mix.w3[3] * dnorm(x, mix.means3[3], 1 / sqrt(mix.precs3[3]))
})

tab.margs <- data.frame(x = c(xx, xx), 
  y = c(mix.marg, mix.marg3),
  grp = rep(c("2 groups", "3 groups"), each = length(xx)))

ggplot(geyser, aes(x = duration)) + 
  geom_histogram(aes(y=..density..), bins = 20) +
  ggtitle("Duration of eruption") +
  geom_line(data = tab.margs, aes(x = x, y = y, linetype = grp)) +
  theme(legend.position = c(0.1, 0.9), legend.title = element_blank())


## -----------------------------------------------------------------------------
library("smcure")
data(e1684)
summary(e1684)


## -----------------------------------------------------------------------------
#Assign labels to factors
e1684$TRT <- as.factor(e1684$TRT)
levels(e1684$TRT) <- c("Control", "IFN")

e1684$SEX <- as.factor(e1684$SEX)
levels(e1684$SEX) <- c("Female", "Male")


## -----------------------------------------------------------------------------
# Remove observation 37 because it has missing values
d <- na.omit(e1684)


## -----------------------------------------------------------------------------
summary(d)


## -----------------------------------------------------------------------------
library("survival")

km <- survfit(Surv(d$FAILTIME, d$FAILCENS) ~ 1)


## ----label = "e1684", fig = TRUE, echo = FALSE, fig.cap = '(ref:e1684)'-------
library("ggfortify")
autoplot(km, censor.colour = "red")


## -----------------------------------------------------------------------------
d.inla <- list(y = inla.surv(d$FAILTIME, d$FAILCENS),
  Treatment = d$TRT, Age = d$AGE, Female = d$SEX)

cure.inla <- inla(y ~ Treatment + Age + Female, family = "weibullcure",
  data = d.inla)
summary(cure.inla)


## -----------------------------------------------------------------------------
weibull.inla <- inla(y ~ Treatment + Age + Female, family = "weibullsurv",
  data = d.inla, control.family = list(list(variant = 0)))
summary(weibull.inla)


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## #Bonemarrow
## data(bmt)
## 
## d.inla <- list(y = inla.surv(bmt$Time, bmt$Status),
##   Treatment = bmt$TRT)
## 
## cure.inla <- inla(y ~ Treatment, family = "weibullcure",
##   data = d.inla)
## summary(cure.inla)

