## ----sett04, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/04-multilevel-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
library("faraway")
data(penicillin)
summary(penicillin)


## ----label = "penicillin", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = '(ref:penicillin)', fig.height = 4----
library("ggplot2")

ggplot(penicillin, aes(x = treat, y = yield, colour = blend)) + geom_point()


## -----------------------------------------------------------------------------
# Set prior on precision
prec.prior <- list(prec = list(param = c(0.001, 0.001)))


## -----------------------------------------------------------------------------
penicillin$treat <- relevel(penicillin$treat, "D")


## -----------------------------------------------------------------------------
library("INLA")
inla.pen <- inla(yield ~ 1 + treat + f(blend, model = "iid",
    hyper = prec.prior),
  data = penicillin, control.predictor = list(compute = TRUE))
summary(inla.pen)


## -----------------------------------------------------------------------------
library("lme4")
lmer.pen <- lmer(yield ~ 1 + treat + (1|blend), data = penicillin)
summary(lmer.pen)


## ----label = "pen", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = "Marginals of fixed effects of the production method (top-left), blend random-effects (top-right), variance of the error term (bottom-left) and variance of the blend effect (bottom-right).", fig.width = 8, fig.height = 6----
# ggplot version
library("ggplot2")
library("gridExtra")


# PLot 1: Treatment effect
tab <- as.data.frame(do.call(rbind, inla.pen$marginals.fixed[2:4]))
tab$lab <- rep(paste("Treat. ", 2:4, sep = ""), each = 75)

p1 <- ggplot(tab, aes(x = x, y = y, linetype = lab)) + geom_line() +
  ggtitle("Treatment effect") +
  theme(legend.position = c(0.15, 0.75), legend.title = element_blank())

# Plot 2: Blend effect
tab <- as.data.frame(do.call(rbind, inla.pen$marginals.random$blend))
tab$lab <- rep(paste("Blend ", 1:5, sep = ""), each = 75)

p2 <- ggplot(tab, aes(x = x, y = y, linetype = lab)) + geom_line() +
  xlim(-5, 5) + ggtitle("Blend effect") +
  theme(legend.position = c(0.15, 0.65), legend.title = element_blank())

# Variances
marg.variances <- lapply(inla.pen$marginals.hyperpar,
  function(m) inla.tmarginal(function(x) 1 / x, m)
)

# Plot 3: Error variance
p3 <- ggplot(as.data.frame(marg.variances[[1]]), aes(x = x, y = y)) +
  geom_line() +
  ggtitle("Error variance") +
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())


# Plot 4: Blend variance
p4 <- ggplot(as.data.frame(marg.variances[[2]]), aes(x = x, y = y)) +
  geom_line() +
  ggtitle("Blend variance") +
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())

grid.arrange(p1, p2, p3, p4, ncol = 2)


## -----------------------------------------------------------------------------
Z <- as(model.matrix(~ 0 + blend, data = penicillin), "Matrix")


## ----label = "Zmatrix", fig = TRUE, fig.align = "center", fig.width = 10, fig.height = 5, echo = FALSE, fig.cap = "Representation of the design matrix of the random effects."----
print(image(Z, xlab = expression(u[j]), ylab = "Observation", sub = ""))


## -----------------------------------------------------------------------------
penicillin$ID <- 1:nrow(penicillin)

inla.pen.z <- inla(yield ~ 1 + treat +  f(ID, model = "z", Z = Z,
  hyper = list(prec = list(param = c(0.001, 0.001)))),
  data = penicillin, control.predictor = list(compute = TRUE))
summary(inla.pen.z)


## ----label = "iid-vs-z", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = '(ref:iid-vs-z)', fig.height = 4----

#Match random effects to data
tab <- data.frame(iid = inla.pen$summary.random$blend$mean,
  z = inla.pen.z$summary.random$ID$mean[20 + 1:5])

ggplot(tab, aes(x = iid, y = z)) + geom_point() +
  geom_abline(intercept = 0, slope = 1)



## -----------------------------------------------------------------------------
data(eggs)

summary(eggs)


## -----------------------------------------------------------------------------
Zlt <- as(model.matrix( ~ 0 + Lab:Technician, data = eggs), "Matrix")
Zlts <- as(model.matrix( ~ 0 + Lab:Technician:Sample, data = eggs), "Matrix")


## -----------------------------------------------------------------------------
# Index for techinician
eggs$IDt <- 1:nrow(eggs)
# Index for technician:sample
eggs$IDts <- 1:nrow(eggs)


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## # This plot does not work in Rmarkdown mode.
## pdf(file = "graphics/multilevel.pdf")
## plot1 <- image(Zlt, xlab = "Random effect", ylab = "Observation",
##   main = "Technician", sub = "")
## plot2 <- image(Zlts, xlab = "Random effect", ylab = "Observation",
##   main = "Sample", sub = "")
## 
## print(plot2, position = c(0.5, 0, 1, 1), more = TRUE)
## print(plot1, position = c(0, 0, 0.5, 1), more = FALSE)
## dev.off()
## 


## ----label = "Z-eggs", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = '(ref:Z-eggs)'----
knitr::include_graphics("graphics/multilevel.pdf")


## -----------------------------------------------------------------------------
inla.eggs <- inla(Fat ~ 1 + f(Lab, model = "iid", hyper = prec.prior) +
    f(IDt, model = "z", Z = Zlt, hyper = prec.prior) +
    f(IDts, model = "z", Z = Zlts, hyper = prec.prior),
  data = eggs, control.predictor = list(compute = TRUE))

summary(inla.eggs)


## -----------------------------------------------------------------------------
eggs$labtech <- as.factor(apply(Zlt, 1, function(x){names(x)[x == 1]}))
eggs$labtechsamp <- as.factor(apply(Zlts, 1, function(x){names(x)[x == 1]}))


## -----------------------------------------------------------------------------
inla.eggs.iid <- inla(Fat ~ 1 + f(Lab, model = "iid", hyper = prec.prior) +
    f(labtech, model = "iid", hyper = prec.prior) +
    f(labtechsamp, model = "iid", hyper = prec.prior),
  data = eggs, control.predictor = list(compute = TRUE))

summary(inla.eggs.iid)



## -----------------------------------------------------------------------------
#Read data
csize_data <- read.csv (file = "data/class_size_data.txt", header = FALSE,
  sep = "", dec = ".")

#Set names
names(csize_data) <- c("clsnr", "pupil", "nlitpre", "nmatpre", "nlitpost",
  "nmatpost", "csize")

#Set NA's
csize_data [csize_data < -1e+29 ] <- NA

#Set class size levels
csize_data$csize <- as.factor(csize_data$csize)
levels(csize_data$csize) <- c("<=19", "20-24", "25-29", ">=30")

summary(csize_data)


## -----------------------------------------------------------------------------
csize_data2 <- na.omit(csize_data[, -5])


## -----------------------------------------------------------------------------
inla.csize <- inla(nmatpost ~ 1 + nmatpre + nlitpre + csize +
  f(clsnr, model = "iid"), data = csize_data2)

summary(inla.csize)


## -----------------------------------------------------------------------------
library("lme4")
data(sleepstudy)


## -----------------------------------------------------------------------------
#Scale Reaction
sleepstudy$Reaction <- sleepstudy$Reaction / 1000


## -----------------------------------------------------------------------------
summary(sleepstudy)


## -----------------------------------------------------------------------------
inla.sleep <- inla(Reaction ~ 1 + Days + f(Subject, model = "iid"),
  data = sleepstudy)


## ----label = "reaction", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = '(ref:reaction)'----
# ggplot2 version
ggplot(sleepstudy, aes(x = Days, y = Reaction)) + geom_point() +
  facet_wrap(~ Subject, ncol = 6) +
  xlab("Days of sleep deprivation") +
  ylab("Average reaction time (s)") +
  geom_smooth(method = 'lm', se = FALSE)



## -----------------------------------------------------------------------------
summary(inla.sleep)


## -----------------------------------------------------------------------------
inla.sleep.w <- inla(Reaction ~ 1 + f(Subject, Days, model = "iid"),
  data = sleepstudy, control.predictor = list(compute = TRUE))


## -----------------------------------------------------------------------------
summary(inla.sleep.w)


## ----label = "sleep-rslope", fig = TRUE, fig.align = "center", echo = FALSE, fig.cap = "Posterior mean of fit line using model with a random slope. The blue line represents a fit line using linear regression and the black line represents the line with the posterior mean of the slope and group effect."----
#Match subjects to groups
idx <- match(sleepstudy$Subject, inla.sleep.w$summary.random$Subject$ID)

# Intercept
sleepstudy$intercept <- inla.sleep.w$summary.fixed[1, "mean"]

# Slope
sleepstudy$slope <- inla.sleep.w$summary.random$Subject$mean[idx]

# ggplot2 version
ggplot(sleepstudy, aes(x = Days, y = Reaction)) + geom_point() +
  facet_wrap(~ Subject, ncol = 6) +
  xlab("Days of sleep deprivation") +
  ylab("Average reaction time (s)") +
  geom_smooth(method = 'lm', se = FALSE) +
  geom_abline(aes(intercept = intercept, slope = slope))


## -----------------------------------------------------------------------------
election88 <- read.table(file = "data/polls.subset.dat")


## -----------------------------------------------------------------------------
election88$age <- as.factor(election88$age)
levels(election88$age) <- c("18-29", "30-44", "45-64", "65+")

election88$edu <- as.factor(election88$edu)
levels(election88$edu) <- c("not.high.school.grad", "high.school.grad",
  "some.college", "college.grad")



## -----------------------------------------------------------------------------
# Add region
election88$region <- c(3, 4, 4, 3, 4, 4, 1, 1, 5, 3, 3, 4, 4, 2, 2, 2, 2,
  3, 3, 1, 1, 1, 2, 2, 3, 2, 4, 2, 4, 1, 1, 4, 1, 3, 2, 2, 3, 4, 1, 1, 3,
  2, 3, 3, 4, 1, 3, 4, 1, 2, 4)[as.numeric(election88$state)]


## -----------------------------------------------------------------------------
inla.elec88 <- inla(bush ~ 1 + female + black + age + edu +
    f(state, model = "iid"),
  data = election88, family = "binomial",
  control.predictor = list(link = 1))

summary(inla.elec88)


## ----label = "eff-state", fig = TRUE, echo = FALSE, fig.cap = "Posterior means and 95% credible intervals of the random effects of the US States."----

USstate.names <- c(state.name[1:8], "Washington D.C.", state.name[9:50])
tab <- data.frame(ID = inla.elec88$summary.random$state$ID,
  State = USstate.names[inla.elec88$summary.random$state$ID],
  mean = inla.elec88$summary.random$state$mean,
  IClower = inla.elec88$summary.random$state[, 4],
  ICupper = inla.elec88$summary.random$state[, 6])

ggplot(data = tab, aes(x = mean, y = ID)) +
  geom_point() +  ylim(1, 51) + xlab(expression(u[j])) + ylab ("State") +
  #FIXME: scale_y_discrete("State", labels = tab$State) + 
  geom_errorbarh(aes(xmin = IClower, xmax = ICupper) ) +
  geom_vline (xintercept = 0, linetype = 2) +
  geom_text(aes(x = -1.1, y = 33.5, label = "New York")) +
  geom_text(aes(x = -1.1, y = 43.5, label = "Tennessee"))


## ----label = "map-eff-state", fig = TRUE, echo = FALSE, fig.cap = "Point estimates of state-level random effect."----
library("sf")
library("USAboundaries")

us.states <- us_states(states = as.character(tab$State))
us.states <- us.states[order(us.states$state_name), ]

us.states$u <- tab$mean[- which(tab$State == "Washington D.C.")]
plot(us.states["u"], key.pos = 4, at = round(seq(-0.6, 0.7, 0.1), 2),
   main = "State effect", pal = rev(hcl.colors(13, "RdBu")))


## -----------------------------------------------------------------------------
nyc.stops <- read.table(file = "data/frisk_with_noise.dat", skip = 6, 
  header = TRUE)

# Add labels to factors
nyc.stops$eth <- as.factor(nyc.stops$eth)
levels(nyc.stops$eth) <- c("black", "hispanic", "white")
nyc.stops$eth <- relevel(nyc.stops$eth, "white")

nyc.stops$crime <- as.factor(nyc.stops$crime)
levels(nyc.stops$crime) <- c("violent", "weapons", "property", "drug")


## -----------------------------------------------------------------------------
nyc.stops.agg <- aggregate(cbind(stops, past.arrests, pop) ~ precinct + eth,
  data = nyc.stops, sum)

# Population is summed 4 times
nyc.stops.agg$pop <- nyc.stops.agg$pop / 4


## -----------------------------------------------------------------------------
nyc.inla <- inla(stops ~ eth + f(precinct, model = "iid"),
  data = nyc.stops.agg, offset = log((15 / 12) * past.arrests),
  family = "poisson")

summary(nyc.inla)


## -----------------------------------------------------------------------------
# Ethnicity precinct index
nyc.stops.agg$ID <- 1:nrow(nyc.stops.agg)
nyc.inla2 <- inla(stops ~ eth + f(precinct, model = "iid") + 
    f(ID, model = "iid"), 
  data = nyc.stops.agg, offset = log((15/12) * past.arrests),
  family = "poisson")

summary(nyc.inla2)


## ----label = "eff-precinct", fig = TRUE, echo = FALSE, fig.cap = "Posterior means and 95% credible intervals of the random effects of the 75 NYC precincts."----
tab <- nyc.inla$summary.random$precinct
names(tab)[c(4, 6)] <- c("IClower", "ICupper")

ggplot(data = tab, aes(x = mean, y = ID)) +
  geom_point() +  ylim(1, 75) + xlab(expression(u[p])) + ylab ("Precinct") +
  geom_errorbarh(aes(xmin = IClower, xmax = ICupper) ) +
  geom_vline (xintercept = 0, linetype = 2)


## -----------------------------------------------------------------------------
# Load precinct data
precinct99 <- read.csv2(file = "data/precinct_data_98-99.csv")
rownames(precinct99) <- precinct99$Precinct

# Order by precinct number
precinct99 <- precinct99[order(precinct99$Precinct), ]

# Remove Central Park
precinct99 <- subset(precinct99, Precinct != 22)


## ----echo = FALSE, eval = FALSE-----------------------------------------------
## # Compute population of precinct in G-H data
## GH.pop <- data.frame(Precicnt = 1:75,
##   Pop = c(by(nyc.stops$pop, nyc.stops$precinct, sum) /4))
## 
## # As percentaje of the population
## pop.race <- matrix(nyc.stops[seq(1, 900, 4), ]$pop, byrow = TRUE, ncol = 3)
## pop.race <- cbind(Precinct = 1:75,
##   as.data.frame(round( 100 * t(apply(pop.race, 1, function(X) X/ sum(X))), 1))
## )
## names(pop.race) [2:4] <- c("black", "hispanic", "white")
## 
## #WARNING: This is fine for precincts with low other population
## # BEWARE of 5, 7
## cbind(pop.race, precinct99[, c(1, 3:6)])


## ----message = FALSE, results = "hide"----------------------------------------
# Test to check boundaries of precincts
library("rgdal")
nyc.precincts <- readOGR("data/Police_Precincts", "nyc_precincts")


## -----------------------------------------------------------------------------
# Set IDs to polygons
for(i in 1:length(nyc.precincts)) {
  slot(slot(nyc.precincts, "polygons")[[i]], "ID") <- 
    as.character(nyc.precincts$precinct[i])
}


## -----------------------------------------------------------------------------
#Merge boundaries and 1999 data
nyc.precincts99 <- SpatialPolygonsDataFrame(nyc.precincts, precinct99)


## -----------------------------------------------------------------------------
# Add r. eff. estimates
nyc.precincts99$u <- nyc.inla$summary.random$precinct$mean


## ----label = "NYC-reff", echo = FALSE, fig = TRUE, fig.cap = "Point estimates of the random effects of the 75 precincts of NYC in 1999.", fig.width = 3.85, fig.height = 3.85, fig.align = "center"----
spplot(nyc.precincts99, "u", col.regions = viridis::magma(20), col = NA)

