## ----sett, echo = FALSE, results = 'hide', message = FALSE, warning = FALSE----
library("knitr")
opts_chunk$set(
  fig.path = 'figs/09-Splines-',
  message = FALSE, warning = FALSE
)
options(width = 75, prompt = " ", continue = "   ", digits = 4)
library("INLA")


## -----------------------------------------------------------------------------
library("SemiPar")
data(lidar)


## ----label = 'lidar', fig = TRUE, echo = FALSE, fig.height = 4, fig.width = 8, fig.cap = '(ref:lidar)'----
library("ggplot2")
ggplot(aes(x = range, y = logratio), data = lidar) + geom_point() +
  ggtitle("LIDAR data")


## -----------------------------------------------------------------------------
xx <- seq(390, 720, by = 5)
# Add data for prediction
new.data <- cbind(range = xx, logratio = NA)
new.data <- rbind(lidar, new.data)


## -----------------------------------------------------------------------------
m.poly <- inla(logratio ~ 1 + range +  I(range^2) + I(range^3),
  data = new.data, control.predictor = list(compute = TRUE))


## ----label = "lidarpoly", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarpoly)', fig.height = 4, fig.width = 8----
tab <- data.frame(x = xx,
  y = m.poly$summary.fitted[-c(1:nrow(lidar)), "mean"],
  ll95 = m.poly$summary.fitted[-c(1:nrow(lidar)), "0.025quant"],
  ul95 = m.poly$summary.fitted[-c(1:nrow(lidar)), "0.975quant"])

ggplot(aes(x = range, y = logratio), data = lidar) + geom_point() +
  ggtitle("LIDAR data") +
  geom_line(aes(x = x, y = y), data = tab, linetype = 1) +
  geom_ribbon(aes(x = x, y = y, ymin = ll95, ymax = ul95), alpha = 0.75, data = tab)



## -----------------------------------------------------------------------------
library("splines")

knots <- seq(400, 700, by = 10)
m.bs3 <- inla(logratio ~ 1 + bs(range, knots = knots),
  data = new.data, control.predictor = list(compute = TRUE))


## -----------------------------------------------------------------------------
m.ns3 <- inla(logratio ~ 1 + ns(range, df = 10),
  data = new.data, control.predictor = list(compute = TRUE))
summary(m.ns3)


## -----------------------------------------------------------------------------
attr(ns(lidar$range, df = 10), "knots")


## ----label = "lidarspl3", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarspl3)', fig.height = 4, fig.width = 8----
tab <- data.frame(x = xx, 
  y.bs3 = m.bs3$summary.fitted[-c(1:nrow(lidar)), "mean"],
  y.ns3 = m.ns3$summary.fitted[-c(1:nrow(lidar)), "mean"])

ggplot(aes(x = range, y = logratio), data = lidar) + geom_point() +
  ggtitle("LIDAR data") +
  geom_line(aes(x = x, y = y.bs3, linetype = "solid"), data = tab) +
  geom_line(aes(x = x, y = y.ns3, linetype = "dashed"), data = tab) +
  geom_point(aes(x = x, y = -1), data = tab, shape = "|") +
  scale_linetype_manual(name = "Model",
    values = c("solid", "dashed"),
    labels = c("Natural spline", "B-spline")) +
  theme(legend.position = "bottom")


## ----label = "coefspl3", fig = TRUE, echo = FALSE, fig.cap = "Estimates (posterior means and 95% credible intervals) of the coefficients of a 3-degree B-spline.",  fig.height = 4, fig.width = 8----
#tab <- data.frame(knot = attr(bs(lidar$range, knots = knots), "knots"))
tab <- data.frame(coef = as.integer(row.names(m.bs3$summary.fixed)[-1]))
tab$mean <- m.bs3$summary.fixed$mean[-1]
tab$LL95 <- m.bs3$summary.fixed[-1, "0.025quant"]
tab$UL95 <- m.bs3$summary.fixed[-1, "0.975quant"]

ggplot(tab, aes(x = coef, y = mean)) + geom_point() + 
  geom_errorbar(aes(ymin = LL95, ymax = UL95)) +
  geom_hline(yintercept = 0, linetype = 2)+
  xlab("Coefficient") +
  ylab("Estimate") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))


## -----------------------------------------------------------------------------
library("INLA")
m.rw1 <- inla(logratio ~ -1 + f(range, model = "rw1", constr = FALSE),
  data = lidar, control.predictor = list(compute = TRUE))
summary(m.rw1)


## -----------------------------------------------------------------------------
m.rw2 <- inla(logratio ~ -1 + f(range, model = "rw2", constr = FALSE),
  data = lidar, control.predictor = list(compute = TRUE))
summary(m.rw2)


## ----label = "lidarsmooth", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarsmooth)',  fig.height = 4, fig.width = 8----
tab.rw1 <- data.frame(x = m.rw1$summary.random$range[, "ID"],
  y = m.rw1$summary.fitted.values[, "mean"])
tab.rw2 <- data.frame(x = m.rw2$summary.random$range[, "ID"],
  y = m.rw2$summary.fitted.values[, "mean"])
ggplot(aes(x = range, y = logratio), data = lidar) + geom_point() +
  ggtitle("LIDAR data") + 
  geom_line(aes(x = x, y = y, linetype = "solid"), data = tab.rw1) +
  geom_line(aes(x = x, y = y, linetype = "dashed"), data = tab.rw2) +
  scale_linetype_manual(name = "Smoothing method",
    values = c("solid", "dashed"),
    labels = c("rw2", "rw1")) +
  theme(legend.position = "bottom")



## -----------------------------------------------------------------------------
lidar$range.grp <- inla.group(lidar$range, n = 20, method = "quantile")
summary(lidar$range.grp)


## -----------------------------------------------------------------------------
m.grp.rw1 <- inla(logratio ~ -1 + f(range.grp, model = "rw1", constr = FALSE),
  data = lidar, control.predictor = list(compute = TRUE))
summary(m.grp.rw1)


## ----label = "lidarbinned", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarbinned)', fig.height = 4, fig.width = 8----
ggplot(lidar, aes(x = range.grp, y = logratio)) +
  geom_point() +
  xlab("Range") +
  ylab("Log-ratio")


## -----------------------------------------------------------------------------
m.grp.rw2 <- inla(logratio ~ -1 + f(range.grp, model = "rw2", constr = FALSE),
  data = lidar, control.predictor = list(compute = TRUE))
summary(m.grp.rw2)


## ----label = "lidarsmooth-grp", fig = TRUE, echo = FALSE, fig.cap = '(ref:lidarsmooth-grp)', fig.height = 4, fig.width = 8----
tab.rw1 <- data.frame(x = m.grp.rw1$summary.random$range[, "ID"],
  y = m.grp.rw1$summary.random$range.grp[, "mean"]
)
tab.rw2 <- data.frame(x = m.grp.rw2$summary.random$range[, "ID"],
  y = m.grp.rw2$summary.random$range.grp[, "mean"]
)

ggplot(aes(x = range, y = logratio), data = lidar) + 
  geom_point(aes(x = lidar$range.grp, y = lidar$logratio), colour = "grey") +
geom_point() +
  ggtitle("LIDAR data") +
  geom_line(aes(x = x, y = y, linetype = "solid"), data = tab.rw1) +
  geom_line(aes(x = x, y = y, linetype = "dashed"), data = tab.rw2) +
  scale_linetype_manual(name = "Smoothing method (grouped range)",
    values = c("solid", "dashed"),
    labels = c("rw2", "rw1")) +
  theme(legend.position = "bottom")


## -----------------------------------------------------------------------------
mesh1d <- inla.mesh.1d(seq(390, 720, by = 20)) 
A1 <- inla.spde.make.A(mesh1d, lidar$range)


## -----------------------------------------------------------------------------

spde1 <- inla.spde2.matern(mesh1d, constr = FALSE)
spde1.idx <- inla.spde.make.index("x", n.spde = spde1$n.spde)


## -----------------------------------------------------------------------------
stack <- inla.stack(data = list(y = lidar$logratio),
  A = list(1, A1),
  effects = list(Intercept = rep(1, nrow(lidar)), spde1.idx),
  tag = "est")


## -----------------------------------------------------------------------------
# Predict at a finer grid
xx <- seq(390, 720, by = 5)
A.xx <- inla.spde.make.A(mesh1d, xx)
stack.pred <- inla.stack(data = list(y = NA),
  A = list(1, A.xx),
  effects = list(Intercept = rep(1, length(xx)), spde1.idx),
  tag = "pred")


## -----------------------------------------------------------------------------
joint.stack <- inla.stack(stack, stack.pred)


## -----------------------------------------------------------------------------
formula <- y ~ -1 + f(x, model = spde1)


## -----------------------------------------------------------------------------
m.spde <- inla(formula, data = inla.stack.data(joint.stack),
  control.predictor = list(A = inla.stack.A(joint.stack), compute = TRUE)
)


## ----fig = TRUE, label = "lidarspde", echo = FALSE, fig.cap = '(ref:lidarspde)', fig.height = 4, fig.width = 8----
idx <- inla.stack.index(joint.stack, 'pred')$data
tab.spde1 <- data.frame(x = xx,
  y = m.spde$summary.fitted.values[idx, "mean"],
  ll95 = m.spde$summary.fitted.values[idx, "0.025quant"],
  ul95 = m.spde$summary.fitted.values[idx, "0.975quant"]
)
ggplot(data = lidar, aes(x = range, y = logratio)) +
  geom_point() +
  ggtitle("LIDAR data") +
  geom_line(aes(x = x, y = y), linetype = 1, data = tab.spde1) +
  geom_ribbon(aes(x = x, y = y, ymin = ll95, ymax = ul95), alpha = 0.2, data = tab.spde1)


## -----------------------------------------------------------------------------
library("drc")

data(H.virescens)
levels(H.virescens$sex) <- c("Female", "Male")
summary(H.virescens)


## -----------------------------------------------------------------------------
vir.rw1 <- inla(numdead ~ -1 + f(dose, model = "rw1", constr = FALSE) + sex,
  data = H.virescens, family ="binomial", Ntrial = total,
  control.predictor = list(compute = TRUE))
summary(vir.rw1)


## -----------------------------------------------------------------------------
vir.rw2 <- inla(numdead ~ -1 + f(dose, model = "rw2", constr = FALSE) + sex,
  data = H.virescens, family = "binomial", Ntrial = total,
  control.predictor = list(compute = TRUE))
summary(vir.rw2)


## ----label = "doserespsmooth", fig = TRUE, echo = FALSE, fig.cap = '(ref:doserespsmooth)', fig.height = 4, fig.width = 8----
tab.rw1 <- data.frame(x = vir.rw1$summary.random$dose[, "ID"],
  y = vir.rw1$summary.random$dose[, "mean"])
tab.rw2 <- data.frame(x = vir.rw2$summary.random$dose[, "ID"],
  y = vir.rw2$summary.random$dose[, "mean"])
ggplot() + #aes(x = dose, y = numdead / total), data = H.virescens) +
   #geom_point() +
  xlab(expression(paste("Dose (", mu, "g)"))) +
  ylab("f(dose)") +  
  ggtitle("Dose response data (smooth term)") +
  geom_line(aes(x = x, y = y, linetype = "solid"), data = tab.rw1) +
  geom_line(aes(x = x, y = y, linetype = "dashed"), data = tab.rw2) +
  scale_linetype_manual(name = "Smoothing method",
    values = c("solid", "dashed"),
    labels = c("rw2", "rw1")) +
  theme(legend.position = "bottom")


## ----label = "doseresp", fig = TRUE, echo = FALSE, fig.cap = '(ref:doseresp)'----
tab.rw1 <- data.frame(x = vir.rw1$summary.random$dose[, "ID"],
  y = vir.rw1$summary.fitted.values[, "mean"], sex = H.virescens$sex)
tab.rw2 <- data.frame(x = vir.rw2$summary.random$dose[, "ID"],
  y = vir.rw2$summary.fitted.values[, "mean"], sex = H.virescens$sex)
ggplot(aes(x = dose, y = numdead / total), data = H.virescens) + 
   geom_point() +
  xlab(expression(paste("Dose (", mu, "g)"))) +
  ylab("Proportion of dead moths") +
  ggtitle("Dose response data (fitted values)") +
  geom_line(aes(x = x, y = y, linetype = "solid"), data = tab.rw1) +
  geom_line(aes(x = x, y = y, linetype = "dashed"), data = tab.rw2) +
  facet_grid(rows = vars(sex)) + 
  scale_linetype_manual(name = "Smoothing method",
    values = c("solid", "dashed"),
    labels = c("rw2", "rw1")) +
  theme(legend.position = "bottom")

