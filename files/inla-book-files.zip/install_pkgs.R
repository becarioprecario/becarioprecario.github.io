#Package installation

#List of packages to install
pkgs <- c("DClusterm", "deldir", "drc", "evd", "faraway", "ggfortify", 
  "gstat", "gpclib", "INLA", "INLABMA", "inlabru", "JMbayes", "KFAS", "latticeExtra", 
  "lme4", "logitnorm", "logitnorm", "mapdata", "maptools", "maptools", 
  "MASS", "mice", "MixtureInf", "osmar", "rgdal", "rjags", "rstan", "rsm",
  "SDraw", "StanHeaders", "scales", "SemiPar", 
  "sf", "smcure", "sp", "spatstat", "spdep", "spelling", "survival", 
  "USAboundaries", "viridis", "viridisLite",
  "bookdown")

#List of repositories to use
repos <- c("https://cloud.r-project.org/",
   "https://inla.r-inla-download.org/R/stable")

#Package installation
install.packages(pkgs, dep = TRUE, repos = repos)
